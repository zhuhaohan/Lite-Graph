/*
 * tsssp_posix.hpp
 *
 *  Created on: Sep 30, 2014
 *      Author: zhu
 */

#ifndef TSSSP_POSIX_HPP_
#define TSSSP_POSIX_HPP_

#include <pthread.h>
#include <vector>

using namespace std;

class TSSSP_Posix
{
    public:
		TSSSP_Posix(int V); // input file
        void initialization(int src, int start, int end);
        int execution(vector< std::pair <int,int> > d_p, vector<Edge> es);
        int execution_es(vector<Edge> es);
        int execution_whole_es(vector<Edge> es, int start, int end);

    public:
    vector< int > node_list_time;

};

TSSSP_Posix::TSSSP_Posix(int V){
    node_list_time.resize(V);
}

void TSSSP_Posix::initialization(int src, int start, int end)
{
    for(int i = 0; i < node_list_time.size(); i++){
        node_list_time[i]= end;
    }
    node_list_time[src] = start;
}

int TSSSP_Posix::execution_es(vector<Edge> es)
{
    bool flag = true;
    int loops = 0;

    while (flag){
        flag = false;
        for(int i=0; i<es.size(); i ++) {
        	cout << i <<endl;
            if(es[i].ts >= node_list_time[es[i].u]) {
        	   if(es[i].te < node_list_time[es[i].v]) {
        		   node_list_time[es[i].v] = es[i].te;
                   flag = true;
        	   }
            }
            else {
            	if(node_list_time[es[i].u] + es[i].te - es[i].ts < node_list_time[es[i].v] && node_list_time[es[i].u] + es[i].te - es[i].ts <= es[i].te) {
            		node_list_time[es[i].v] = node_list_time[es[i].u] + es[i].te - es[i].ts;
            		flag = true;
            	}
            }
        }
        loops++;
    }
    return loops;
}

int TSSSP_Posix::execution(vector< std::pair <int,int> > d_p, vector<Edge> es)
{
    bool flag = true;
    int loops = 0;

    while (flag){
        flag = false;
    	for(int i = 0; i < d_p.size(); i++){
    		for(int j = d_p[i].first; j <= d_p[i].second; j++){
    			if(es[j].ts >= node_list_time[es[j].u]) {
    				if(es[j].te < node_list_time[es[j].v]) {
        		   	   node_list_time[es[j].v] = es[j].te;
                   	   flag = true;
        	   	   }
            	}
            	else {
            		if(node_list_time[es[j].u] + es[i].te - es[i].ts < node_list_time[es[j].v] && node_list_time[es[j].u] + es[i].te - es[i].ts <= es[j].te) {
            			node_list_time[es[j].v] = node_list_time[es[j].u] + es[i].te - es[i].ts;
            			flag = true;
            		}
            	}
    		}
    	}
        loops++;
    }
    return loops;
}

int TSSSP_Posix::execution_whole_es(vector<Edge> es, int start, int end)
{
    bool flag = true;
    int loops = 0;

    while (flag){
        flag = false;
        for(int i=0; i<es.size(); i ++) {
            if(es[i].ts >= start && es[i].te <= end) {
            	if(es[i].ts >= node_list_time[es[i].u]) {
            		if(es[i].te < node_list_time[es[i].v]) {
            			node_list_time[es[i].v] = es[i].te;
            			flag = true;
            		}
            	}
            	else {
            		if(node_list_time[es[i].u] + es[i].te - es[i].ts < node_list_time[es[i].v] && node_list_time[es[i].u] + es[i].te - es[i].ts <= es[i].te) {
            			node_list_time[es[i].v] = node_list_time[es[i].u] + es[i].te - es[i].ts;
            			flag = true;
            		}
            	}
            }
        }
        loops++;
    }
    return loops;
}


#endif /* TSSSP_POSIX_HPP_ */
