/*
 * load_graph_delta.hpp
 *
 *  Created on: Nov 3, 2014
 *      Author: zhu
 */

#ifndef LOAD_GRAPH_DELTA_HPP_
#define LOAD_GRAPH_DELTA_HPP_

#include <vector>
#include <map>
#include <iostream>
#include <fstream>
#include <string>
#include <boost/lexical_cast.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>

using namespace std;
using namespace boost;

struct Delta
{
    int id, t, o;
    bool operator < (const Delta that) const {
        if (t != that.t)
            return t < that.t;
        else if (id != that.id)
            return id < that.id;
        else
            return o < that.o;
    }
};

class Graph_Delta
{
    public:
		Graph_Delta(const char* READ_DELTA_FILE); // load whole graph

    public:
		map< int, vector<Delta> > deltas;
};

Graph_Delta::Graph_Delta(const char* READ_DELTA_FILE) {
	string delta_line;
    ifstream deltafile (READ_DELTA_FILE);
    if (deltafile.is_open()) {
        while(getline(deltafile,delta_line))
        {
        	vector<Delta> delta_vector;
        	size_t found = delta_line.find(':');
        	int interval = lexical_cast<int>(delta_line.substr(0, found));
        	string value = delta_line.substr(found+1);
            char_separator<char> sep("\t");
            tokenizer< char_separator<char> > tokens(value, sep);
            BOOST_FOREACH (const string& t, tokens) {
            	size_t found_id = t.find(',');
            	int id = lexical_cast<int>(t.substr(0, found_id));
            	size_t found_time = t.find(',', found_id+1);
            	int time = lexical_cast<int>(t.substr(found_id+1, found_time-found_id-1));
            	int operation = lexical_cast<int>(t.substr(found_time+1));
            	Delta d;
            	d.id = id;
            	d.t = time;
            	d.o = operation;
            	delta_vector.push_back(d);
            }
            deltas.insert(pair< int, vector<Delta> >(interval, delta_vector));
        }
        deltafile.close();
    }
    else cout << "Unable to open delta file";
};

#endif /* LOAD_GRAPH_DELTA_HPP_ */
