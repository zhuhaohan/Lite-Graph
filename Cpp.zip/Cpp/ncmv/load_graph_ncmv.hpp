/*
 * load_graph_ncmv.hpp
 *
 *  Created on: Oct 20, 2014
 *      Author: zhu
 */

#ifndef LOAD_GRAPH_NCMV_HPP_
#define LOAD_GRAPH_NCMV_HPP_

#include <vector>
#include <map>
#include <iostream>
#include <fstream>
#include <string>
#include <boost/lexical_cast.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>

using namespace std;
using namespace boost;

struct Edge
{
    int v, ts, te;
    bool operator < (const Edge that) const {
        if (ts != that.ts)
            return ts < that.ts;
        else if (te != that.te)
            return te < that.te;
        else
        	return v < that.v;
    }
};

class Graph_NCMV
{
    public:
		Graph_NCMV(const char* READ_FILE); // load whole graph

    public:
		map< int, vector<Edge> > ncmv_map;
		int E;
		int V;
};

Graph_NCMV::Graph_NCMV(const char* READ_FILE) {
	string line;
    ifstream myfile (READ_FILE);
    if (myfile.is_open())
      {
    	int count_nodes = 0;
    	int count_edges = 0;
        while(getline(myfile,line))
        {
        	count_nodes++;
        	vector<Edge> neighbors;
        	size_t found = line.find(':');
        	int src = lexical_cast<int>(line.substr(0, found));
        	string value = line.substr(found+1);
            char_separator<char> sep("\t");
            tokenizer< char_separator<char> > tokens(value, sep);
            BOOST_FOREACH (const string& t, tokens) {
            	size_t found_dst = t.find(',');
            	int dst = lexical_cast<int>(t.substr(0, found_dst));
            	size_t found_stime = t.find(',', found_dst+1);
            	int stime = lexical_cast<int>(t.substr(found_dst+1, found_stime-found_dst-1));
            	int etime = lexical_cast<int>(t.substr(found_stime+1));
            	Edge e;
            	e.v = dst;
            	e.ts = stime;
            	e.te = etime;
            	neighbors.push_back(e);
            	count_edges++;
            }
            ncmv_map.insert(pair< int, vector<Edge> >(src, neighbors));
        }
        myfile.close();
        V = count_nodes;
        E = count_edges;
      }
    else cout << "Unable to open file";
};

#endif /* LOAD_GRAPH_NCMV_HPP_ */
