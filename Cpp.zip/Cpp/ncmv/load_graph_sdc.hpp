/*
 * load_graph_sdc.hpp
 *
 *  Created on: Oct 20, 2014
 *      Author: zhu
 */

#ifndef LOAD_GRAPH_SDC_HPP_
#define LOAD_GRAPH_SDC_HPP_

#include <vector>
#include <map>
#include <iostream>
#include <fstream>
#include <string>
#include <boost/lexical_cast.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>

using namespace std;
using namespace boost;

struct Edge
{
    int u, v, ts, te;
    bool operator < (const Edge that) const {
        if (u != that.u)
            return u < that.u;
        else if (v != that.v)
            return v < that.v;
        else if (ts != that.ts)
            return ts < that.ts;
        else
            return te < that.te;
    }
};

struct Edge_Delta
{
    int u, v, ts, te, o;
    bool operator < (const Edge_Delta that) const {
        if (u != that.u)
            return u < that.u;
        else if (v != that.v)
            return v < that.v;
        else if (ts != that.ts)
            return ts < that.ts;
        else if (te != that.te)
        	return te < that.te;
        else
            return o < that.o;
    }
};

class Graph_SDC
{
    public:
		Graph_SDC(const char* READ_DELTA_FILE, const char* READ_SNAPSHOT_FILE); // load whole graph

    public:
		map< int, vector<Edge_Delta> > deltas;
		map< int, vector<Edge> > snapshots;
};

Graph_SDC::Graph_SDC(const char* READ_DELTA_FILE, const char* READ_SNAPSHOT_FILE) {
	string delta_line;
    ifstream deltafile (READ_DELTA_FILE);
    if (deltafile.is_open()) {
        while(getline(deltafile,delta_line))
        {
        	vector<Edge_Delta> delta_vector;
        	size_t found = delta_line.find(':');
        	int time = lexical_cast<int>(delta_line.substr(0, found));
        	string value = delta_line.substr(found+1);
            char_separator<char> sep("\t");
            tokenizer< char_separator<char> > tokens(value, sep);
            BOOST_FOREACH (const string& t, tokens) {
            	size_t found_src = t.find(',');
            	int src = lexical_cast<int>(t.substr(0, found_src));
            	size_t found_dst = t.find(',', found_src+1);
            	int dst = lexical_cast<int>(t.substr(found_src+1, found_dst-found_src-1));
            	size_t found_stime = t.find(',', found_dst+1);
            	int s_time = lexical_cast<int>(t.substr(found_dst+1, found_stime-found_dst-1));
            	size_t found_etime = t.find(',', found_stime+1);
            	int e_time = lexical_cast<int>(t.substr(found_stime+1, found_etime-found_stime-1));
            	int operation = lexical_cast<int>(t.substr(found_etime+1));
            	Edge_Delta e_d;
            	e_d.u = src;
            	e_d.v = dst;
            	e_d.ts = s_time;
            	e_d.te = e_time;
            	e_d.o = operation;
            	delta_vector.push_back(e_d);
            }
            deltas.insert(pair< int, vector<Edge_Delta> >(time, delta_vector));
        }
        deltafile.close();
    }
    else cout << "Unable to open delta file";

	string snapshot_line;
    ifstream snapshotfile (READ_SNAPSHOT_FILE);
    if (snapshotfile.is_open()) {
        while(getline(snapshotfile,snapshot_line))
        {
        	vector<Edge> snapshot_vector;
        	size_t found = snapshot_line.find(':');
        	int time = lexical_cast<int>(snapshot_line.substr(0, found));
        	string value = snapshot_line.substr(found+1);
            char_separator<char> sep("\t");
            tokenizer< char_separator<char> > tokens(value, sep);
            BOOST_FOREACH (const string& t, tokens) {
            	size_t found_src = t.find(',');
            	int src = lexical_cast<int>(t.substr(0, found_src));
            	size_t found_dst = t.find(',', found_src+1);
            	int dst = lexical_cast<int>(t.substr(found_src+1, found_dst-found_src-1));
            	size_t found_time = t.find(',', found_dst+1);
            	int stime = lexical_cast<int>(t.substr(found_dst+1, found_time-found_dst-1));
            	int etime = lexical_cast<int>(t.substr(found_time+1));
            	Edge e;
            	e.u = src;
            	e.v = dst;
            	e.ts = stime;
            	e.te = etime;
            	snapshot_vector.push_back(e);
            }
            snapshots.insert(pair< int, vector<Edge> >(time, snapshot_vector));
        }
        snapshotfile.close();
    }
    else cout << "Unable to open snapshot file";
};

#endif /* LOAD_GRAPH_SDC_HPP_ */
