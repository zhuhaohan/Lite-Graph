/*
 * ncmv.cpp
 *
 *  Created on: Oct 20, 2014
 *      Author: zhu
 */

#include "timer.hpp"
#include "load_graph_ncmv.hpp"
#include <vector>
#include <map>

using namespace std;

int main(){

    int FL_time_array[] = {394563, 1643905, 2883713, 4134935, 5345876, 6543791, 7665540, 8791575, 9707029, 10608420, 11493442};
    int NF_time_array[] = {32004043, 122248287, 131242146, 136468377, 150778804, 156492861, 166278703, 176471905, 195747318, 203198733, 211273538};
    int AS_time_array[] = {248,1442, 2360, 3115, 3660, 4119, 4543, 4843, 5103, 5353, 5533};
    int CPN_time_array[] = {2, 75, 149, 223, 297, 369, 443, 515, 587, 617, 717};
    int CP_time_array[] = {0, 73, 147, 221, 295, 367, 441, 513, 585, 615, 715};
    int TA_time_array[] = {21168000, 39997627, 69002340, 83989380, 99258312, 113601360, 128569680, 142647060, 157772520, 172192393, 187568220};
    int FL_Duration = 11179999;
    int TA_Duration = 168313451;
    int NF_Duration = 181291836;
    int AS_Duration = 5476;
    int CP_Duration = 729;

    int start = FL_time_array[2];
    int end = FL_time_array[3];
    int delta = FL_Duration/10000;

    int E = 120000000;// FL 120000000; TA 800000000; NF 1500000000; AS 5000000; CP 200000000;

    const char* data_file = "/research/datasets/TGA/zhu/NCMV/FL_NCMV";

    Timer read_graph;
    read_graph.start();
    Graph_NCMV g(data_file);
    read_graph.stop();
    //cout << "Reading Graphs:\t" << read_graph.elapsed_time() << "  \t seconds" << endl;
    //cout << "# Nodes:\t" <<g.V << endl;
    //cout << "# Edges:\t" <<g.E << endl;

    cout << "*********************************************************" << endl;
    vector<int> cs_result;
    Timer cs_time;
    cs_time.start();
    map< int, vector<Edge> >::iterator csit;
    for (csit = g.ncmv_map.begin(); csit!=g.ncmv_map.end(); ++csit) {
    	vector<Edge> edges = csit->second;
    	for(int i  = 0; i < edges.size(); i++){
			if(edges[i].te <= end) {
				if(edges[i].ts >= start){
					cs_result.push_back(i);
				}
			}
			if (edges[i].ts > end)
				break;
    	}
    }
    cs_time.stop();
    cout << "Covering Snapshot:\t" << cs_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Covering Snapshot Results:\t" << cs_result.size() << endl;
    cout << "*********************************************************" << endl;

    vector<int> es_result;
    Timer es_time;
    es_time.start();
    map< int, vector<Edge> >::iterator esit;
    for (esit = g.ncmv_map.begin(); esit!=g.ncmv_map.end(); ++esit) {
    	vector<Edge> edges = esit->second;
    	for(int i  = 0; i < edges.size(); i++){
    		if(edges[i].ts <= end) {
    			if(edges[i].te >= start) {
					es_result.push_back(i);
				}
			}
    		else {
				break;
    		}
    	}
    }
    es_time.stop();
    cout << "Existing Snapshot:\t" << es_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Existing Snapshot Results:\t" << es_result.size() << endl;
    cout << "*********************************************************" << endl;

    vector<int> ps_result;
    Timer ps_time;
    ps_time.start();
    map< int, vector<Edge> >::iterator psit;
    for (psit = g.ncmv_map.begin(); psit!=g.ncmv_map.end(); ++psit) {
    	vector<Edge> edges = psit->second;
    	for(int i  = 0; i < edges.size(); i++){
    		if(edges[i].ts <= start) {
    			if(edges[i].te >= start + delta) {
					ps_result.push_back(i);
				}
			}
    		else {
				break;
    		}
    	}
    }
    ps_time.stop();
    cout << "Persisting Snapshot:\t" << ps_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Persisting Snapshot Results:\t" << ps_result.size() << endl;
    cout << "*********************************************************" << endl;

    vector<int> cad_result;
    Timer cad_time;
    cad_time.start();
    map< int, vector<Edge> >::iterator cadit;
    for (cadit = g.ncmv_map.begin(); cadit!=g.ncmv_map.end(); ++cadit) {
    	vector<Edge> edges = cadit->second;
    	for(int i  = 0; i < edges.size(); i++){
			if(edges[i].te <= end + delta) {
				if(edges[i].te >= end){
					if(edges[i].ts >= start + delta){
						cad_result.push_back(i);
					}
				}
			}
    	}
    }
    cad_time.stop();
    cout << "Covering Adding Delta:\t" << cad_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Covering Adding Delta Results:\t" << cad_result.size() << endl;
    cout << "*********************************************************" << endl;

    vector<int> crd_result;
    Timer crd_time;
    crd_time.start();
    map< int, vector<Edge> >::iterator crdit;
    for (crdit = g.ncmv_map.begin(); crdit!=g.ncmv_map.end(); ++crdit) {
    	vector<Edge> edges = crdit->second;
    	for(int i  = 0; i < edges.size(); i++){
			if(edges[i].ts <= start + delta) {
				if(edges[i].ts >= start){
					if(edges[i].te <= end){
						crd_result.push_back(i);
					}
				}
			}
			else {
				break;
			}
    	}
    }
    crd_time.stop();
    cout << "Covering Removing Delta:\t" << crd_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Covering Removing Delta Results:\t" << crd_result.size() << endl;
    cout << "*********************************************************" << endl;

    vector<int> ead_result;
    Timer ead_time;
    ead_time.start();
    map< int, vector<Edge> >::iterator eadit;
    for (eadit = g.ncmv_map.begin(); eadit!=g.ncmv_map.end(); ++eadit) {
    	vector<Edge> edges = eadit->second;
    	for(int i  = 0; i < edges.size(); i++){
			if(edges[i].ts <= end + delta) {
				if(edges[i].ts >= end){
					if(edges[i].te >= start + delta){
						ead_result.push_back(i);
					}
				}
			}
			else {
				break;
			}
    	}
    }
    ead_time.stop();
    cout << "Existing Adding Delta:\t" << ead_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Existing Adding Delta Results:\t" << ead_result.size() << endl;
    cout << "*********************************************************" << endl;

    vector<int> erd_result;
    Timer erd_time;
    erd_time.start();
    map< int, vector<Edge> >::iterator erdit;
    for (erdit = g.ncmv_map.begin(); erdit!=g.ncmv_map.end(); ++erdit) {
    	vector<Edge> edges = erdit->second;
    	for(int i  = 0; i < edges.size(); i++){
			if(edges[i].ts <= end) {
				if(edges[i].te >= start){
					if(edges[i].te <= start + delta){
						erd_result.push_back(i);
					}
				}
			}
			else {
				break;
			}
    	}
    }
    erd_time.stop();
    cout << "Existing Removing Delta:\t" << erd_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Existing Removing Delta Results:\t" << erd_result.size() << endl;
    cout << "*********************************************************" << endl;

    vector<int> pad_result;
    Timer pad_time;
    pad_time.start();
    map< int, vector<Edge> >::iterator padit;
    for (padit = g.ncmv_map.begin(); padit!=g.ncmv_map.end(); ++padit) {
    	vector<Edge> edges = padit->second;
    	for(int i  = 0; i < edges.size(); i++){
			if(edges[i].ts <= start + delta) {
				if(edges[i].ts >= start){
					if(edges[i].te >= end + delta){
						pad_result.push_back(i);
					}
				}
			}
			else {
				break;
			}
    	}
    }
    pad_time.stop();
    cout << "Persisting Adding Delta:\t" << pad_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Persisting Adding Delta Results:\t" << pad_result.size() << endl;
    cout << "*********************************************************" << endl;

    vector<int> prd_result;
    Timer prd_time;
    prd_time.start();
    map< int, vector<Edge> >::iterator prdit;
    for (prdit = g.ncmv_map.begin(); prdit!=g.ncmv_map.end(); ++prdit) {
    	vector<Edge> edges = prdit->second;
    	for(int i  = 0; i < edges.size(); i++){
			if(edges[i].ts <= start) {
				if(edges[i].te >= end){
					if(edges[i].te <= end + delta){
						prd_result.push_back(i);
					}
				}
			}
			else {
				break;
			}
    	}
    }
    prd_time.stop();
    cout << "Persisting Removing Delta:\t" << prd_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Persisting Removing Delta Results:\t" << prd_result.size() << endl;
    cout << "*********************************************************" << endl;

    return 0;
}
