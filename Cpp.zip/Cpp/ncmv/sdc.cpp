/*
 * sdc.cpp
 *
 *  Created on: Oct 20, 2014
 *      Author: zhu
 */

#include "timer.hpp"
#include "load_graph_delta.hpp"
#include <set>

using namespace std;

int main(){

    int FL_time_array[] = {394563, 1643905, 2883713, 4134935, 5345876, 6543791, 7665540, 8791575, 9707029, 10608420, 11493442};
    int NF_time_array[] = {32004043, 122248287, 131242146, 136468377, 150778804, 156492861, 166278703, 176471905, 195747318, 203198733, 211273538};
    int AS_time_array[] = {248,1442, 2360, 3115, 3660, 4119, 4543, 4843, 5103, 5353, 5533};
    int CPN_time_array[] = {2, 75, 149, 223, 297, 369, 443, 515, 587, 617, 717};
    int CP_time_array[] = {0, 73, 147, 221, 295, 367, 441, 513, 585, 615, 715};
    int TA_time_array[] = {21168000, 39997627, 69002340, 83989380, 99258312, 113601360, 128569680, 142647060, 157772520, 172192393, 187568220};
    int FL_Duration = 11179999;
    int TA_Duration = 168313451;
    int NF_Duration = 181291836;
    int AS_Duration = 5476;
    int CP_Duration = 729;

    int start = FL_time_array[2];
    int end = FL_time_array[3];
    int delta = FL_Duration/10000;
    int interval = 100;

    int minInterval = start / interval;
    int maxInterval = end / interval;
    int minDeltaInterval = (start+delta) /interval;
    int maxDeltaInterval = (end+delta) /interval;

    const char* delta_file = "/research/datasets/TGA/zhu/SDC/FL_DE_100";

    Timer read_graph;
    read_graph.start();
    Graph_Delta g(delta_file);
    read_graph.stop();
    //cout << "Reading Graphs:\t" << read_graph.elapsed_time() << "  \t seconds" << endl;
    cout << "*********************************************************" << endl;

    set<int> cs_candidates;
    set<int> cs_result;
    Timer cs_time;
    cs_time.start();
    map< int, vector<Delta> >::iterator csdit;
    for (csdit = g.deltas.begin(); csdit!=g.deltas.end(); ++csdit) {
    	if(csdit->first <= maxInterval){
    		if(csdit->first >= minInterval) {
    			vector<Delta> edges = csdit->second;
    			for(int i  = 0; i < edges.size(); i++){
    				if(edges[i].t <= end) {
    					if(edges[i].t >= start) {
    						if(edges[i].o == 0){
    							cs_candidates.insert(edges[i].id);
    						}
    						else {
    							if(cs_candidates.find(edges[i].id) != cs_candidates.end())
    								cs_result.insert(edges[i].id);
    						}
    					}
    				}
    				else {
    					break;
    				}
    			}
    		}
    	}
    	else {
    		break;
    	}
    }
    cs_time.stop();
    cout << "Covering Snapshot:\t" << cs_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Covering Snapshot Results:\t" << cs_result.size() << endl;
    cout << "*********************************************************" << endl;

    set<int> es_candidates;
    set<int> es_result;
    Timer es_time;
    es_time.start();
    map< int, vector<Delta> >::iterator esdit;
    for (esdit = g.deltas.begin(); esdit!=g.deltas.end(); ++esdit) {
    	if(esdit->first <= maxInterval){
        	vector<Delta> edges = esdit->second;
        	for(int i  = 0; i < edges.size(); i++){
        		if(edges[i].t < start) {
        			if(edges[i].o == 0) {
        				es_candidates.insert(edges[i].id);
        			}
        			else {
        				es_candidates.erase(es_candidates.find(edges[i].id));
        			}
        		}
        		else if(edges[i].t <= end) {
            		if(edges[i].o == 0){
            			es_result.insert(edges[i].id);
            		}
        		}
        		else {
        			es_result.insert(es_candidates.begin(), es_candidates.end());
        			break;
        		}
        	}
    	}
    	else {
    		break;
    	}
    }
    es_time.stop();
    cout << "Existing Snapshot:\t" << es_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Existing Snapshot Results:\t" << es_result.size() << endl;
    cout << "*********************************************************" << endl;

    set<int> ps_candidates;
    set<int> ps_result;
    Timer ps_time;
    ps_time.start();
    map< int, vector<Delta> >::iterator psdit;
    for (psdit = g.deltas.begin(); psdit!=g.deltas.end(); ++psdit) {
    	if(psdit->first <= minDeltaInterval){
        	vector<Delta> edges = psdit->second;
        	for(int i  = 0; i < edges.size(); i++){
        		if(edges[i].t <= start+delta) {
            		if(edges[i].o == 0){
            			if(edges[i].t <= start)
            				ps_candidates.insert(edges[i].id);
            		}
            		else {
        				if(ps_candidates.find(edges[i].id) != ps_candidates.end())
        					ps_candidates.erase(ps_candidates.find(edges[i].id));
            		}
        		}
        		else {
        			ps_result.insert(ps_candidates.begin(), ps_candidates.end());
        			break;
        		}
        	}
    	}
    	else {
    		break;
    	}
    }
    ps_time.stop();
    cout << "Persisting Snapshot:\t" << ps_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Persisting Snapshot Results:\t" << ps_result.size() << endl;
    cout << "*********************************************************" << endl;

    set<int> cad_candidates;
    set<int> cad_result;
    Timer cad_time;
    cad_time.start();
    map< int, vector<Delta> >::iterator caddit;
    for (caddit = g.deltas.begin(); caddit!=g.deltas.end(); ++caddit) {
    	if(caddit->first <= maxDeltaInterval) {
    		if(caddit->first >= minDeltaInterval) {
    			vector<Delta> edges = caddit->second;
    			for(int i  = 0; i < edges.size(); i++){
    				if(edges[i].t <= end + delta) {
   						if(edges[i].o == 0){
   							if(edges[i].t >= start + delta)
   								cad_candidates.insert(edges[i].id);
   						}
   						else {
   							if(edges[i].t >= end)
   								if(cad_candidates.find(edges[i].id) != cad_candidates.end())
   									cad_result.insert(edges[i].id);
   						}
    				}
    				else {
    					break;
    				}
    			}
        	}
    	}
    	else {
    		break;
    	}
    }
    cad_time.stop();
    cout << "Covering Adding Delta:\t" << cad_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Covering Adding Delta Results:\t" << cad_result.size() << endl;
    cout << "*********************************************************" << endl;

    set<int> crd_candidates;
    set<int> crd_result;
    Timer crd_time;
    crd_time.start();
    map< int, vector<Delta> >::iterator crddit;
    for (crddit = g.deltas.begin(); crddit!=g.deltas.end(); ++crddit) {
    	if(crddit->first <= maxInterval) {
    		if(crddit->first >= minInterval) {
    			vector<Delta> edges = crddit->second;
    			for(int i  = 0; i < edges.size(); i++){
    				if(edges[i].t <= end) {
   						if(edges[i].o == 0){
   							if (edges[i].t <= start + delta)
   								if (edges[i].t >= start)
   									crd_candidates.insert(edges[i].id);
   						}
   						else {
   							if(crd_candidates.find(edges[i].id) != crd_candidates.end())
   								crd_result.insert(edges[i].id);
   						}
    				}
    				else {
    					break;
    				}
    			}
        	}
    	}
    	else {
    		break;
    	}
    }
    crd_time.stop();
    cout << "Covering Removing Delta:\t" << crd_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Covering Removing Delta Results:\t" << crd_result.size() << endl;
    cout << "*********************************************************" << endl;

    set<int> ead_result;
    Timer ead_time;
    ead_time.start();
    map< int, vector<Delta> >::iterator eaddit;
    for (eaddit = g.deltas.begin(); eaddit!=g.deltas.end(); ++eaddit) {
    	if(eaddit->first <= maxDeltaInterval) {
    		if(eaddit->first >= maxInterval) {
    			vector<Delta> edges = eaddit->second;
    			for(int i  = 0; i < edges.size(); i++){
    				if(edges[i].t <= end + delta) {
   						if(edges[i].o == 0){
   							if (edges[i].t >= end)
   								ead_result.insert(edges[i].id);
   						}
    				}
    				else {
    					break;
    				}
    			}
        	}
    	}
    	else {
    		break;
    	}
    }
    ead_time.stop();
    cout << "Existing Adding Delta:\t" << ead_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Existing Adding Delta Results:\t" << ead_result.size() << endl;
    cout << "*********************************************************" << endl;

    set<int> erd_result;
    Timer erd_time;
    erd_time.start();
    map< int, vector<Delta> >::iterator erddit;
    for (erddit = g.deltas.begin(); erddit!=g.deltas.end(); ++erddit) {
    	if(erddit->first <= minDeltaInterval) {
    		vector<Delta> edges = erddit->second;
    		for(int i  = 0; i < edges.size(); i++){
    			if(edges[i].t <= start + delta) {
   					if(edges[i].o == 1){
   						if (edges[i].t >= start)
   							erd_result.insert(edges[i].id);
   					}
    			}
    			else {
    				break;
    			}
    		}
    	}
    	else {
    		break;
    	}
    }
    erd_time.stop();
    cout << "Existing Removing Delta:\t" << erd_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Existing Removing Delta Results:\t" << erd_result.size() << endl;
    cout << "*********************************************************" << endl;

    set<int> pad_candidates;
    set<int> pad_result;
    Timer pad_time;
    pad_time.start();
    map< int, vector<Delta> >::iterator paddit;
    for (paddit = g.deltas.begin(); paddit!=g.deltas.end(); ++paddit) {
    	if(paddit->first <= maxDeltaInterval) {
    		if(paddit->first >= minInterval) {
    			vector<Delta> edges = paddit->second;
    			for(int i  = 0; i < edges.size(); i++){
    				if(edges[i].t <= end + delta) {
    					if(edges[i].t >= start) {
    						if(edges[i].o == 0){
    							if (edges[i].t <= start + delta)
    								pad_candidates.insert(edges[i].id);
    						}
    						else{
       							if(pad_candidates.find(edges[i].id) != pad_candidates.end())
       								pad_candidates.erase(pad_candidates.find(edges[i].id));
    						}
    					}
    				}
    				else {
    					pad_result.insert(pad_candidates.begin(), pad_candidates.end());
    					break;
    				}
    			}
        	}
    	}
    	else {
    		break;
    	}
    }
    pad_time.stop();
    cout << "Persisting Adding Delta:\t" << pad_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Persisting Adding Delta Results:\t" << pad_result.size() << endl;
    cout << "*********************************************************" << endl;

    set<int> prd_candidates;
    set<int> prd_result;
    Timer prd_time;
    prd_time.start();
    map< int, vector<Delta> >::iterator prddit;
    for (prddit = g.deltas.begin(); prddit!=g.deltas.end(); ++prddit) {
    	if(prddit->first <= maxDeltaInterval) {
    		vector<Delta> edges = prddit->second;
    		for(int i  = 0; i < edges.size(); i++){
    			if(edges[i].t <= end + delta) {
   					if(edges[i].o == 0) {
   						if (edges[i].t <= start)
   							prd_candidates.insert(edges[i].id);
   					}
   					else {
   						if (edges[i].t >= end)
   							if(prd_candidates.find(edges[i].id) != prd_candidates.end())
   								prd_result.insert(edges[i].id);
   					}
    			}
    			else {
    				break;
    			}
    		}
    	}
    	else {
    		break;
    	}
    }
    prd_time.stop();
    cout << "Persisting Removing Delta:\t" << prd_time.elapsed_time() << "  \t seconds" << endl;
    cout << "# Persisting Removing Delta Results:\t" << prd_result.size() << endl;
    cout << "*********************************************************" << endl;

    return 0;
}
