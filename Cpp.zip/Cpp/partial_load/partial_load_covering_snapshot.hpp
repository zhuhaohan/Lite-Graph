/*
 * partial_load_covering_snapshot.hpp
 *
 *  Created on: Oct 24, 2014
 *      Author: zhu
 */

#ifndef PARTIAL_LOAD_COVERING_SNAPSHOT_HPP_
#define PARTIAL_LOAD_COVERING_SNAPSHOT_HPP_

#include <vector>
#include <iostream>
#include <fstream>
#include "index.hpp"

using namespace std;

struct Edge
{
    int u, v, ts, te;
    bool operator < (const Edge that) const {
        if (ts != that.ts)
            return ts < that.ts;
        if (te != that.te)
            return te > that.te;
        if (u != that.u)
            return u < that.u;
        else
        	return v < that.v;
    }
};

class Partial_Load_Covering_Snapshot
{
    public:
		Partial_Load_Covering_Snapshot(const char* file_name, Index index_structure, int start_input, int end_input, int memory_input);
		void load(int begin);
		int binary_search(int begin, int end, int key);
		void get_duration_pairs(int begin, int memory_size);
		void retrieve_results();

    public:
		const char* graph_file;
        Index index;
        int x, y;
        int M;
        int index_min, index_max;
        int B; // B for # buckets
        vector<Edge> candidates;
        vector< std::pair <int,int> > duration_pairs;
        int number_results;
        vector<Edge> results;
};

Partial_Load_Covering_Snapshot::Partial_Load_Covering_Snapshot(const char* file_name, Index index_structure, int start_input, int end_input, int memory_input) {
	graph_file = file_name;
	index = index_structure;
	x = start_input;
	y = end_input;
	M = memory_input;
	index_min = index.start_index(x);
	index_max = index.end_index(y);
	B = (index_max - index_min) / index.bucket_size;
	candidates.resize(M*index.bucket_size);
	candidates.empty();
	duration_pairs.empty();
	number_results = 0;
}

void Partial_Load_Covering_Snapshot::load(int begin) {
    //ifstream binary_file (graph_file, ios::in | ios::binary);
    ifstream binary_file;
    binary_file.rdbuf()->pubsetbuf(0, 0);
    binary_file.open(graph_file,  ios::in | ios::binary);
    binary_file.seekg(sizeof(struct Edge)*(begin*index.bucket_size+index_min), ios::beg);
    if(begin*index.bucket_size + index_min + M*index.bucket_size > index_max) {
        candidates.resize(index_max - begin*index.bucket_size - index_min);
    	binary_file.read ((char*)&candidates[0], sizeof(struct Edge)*(index_max - begin*index.bucket_size - index_min));
    }
    else {
        binary_file.read ((char*)&candidates[0], sizeof(struct Edge)*(M*index.bucket_size));
    }
    binary_file.close();
};

void Partial_Load_Covering_Snapshot::get_duration_pairs(int begin, int memory_size) {
	if(begin == 0) {
		for(int j = 0; j < index.bucket_size; j++){ // [x, y] for bucket with x
			if(candidates[j].te <= y) {
				if(candidates[j].ts >= x){
					duration_pairs.push_back(make_pair(j, j));
					number_results++;
				}
			}
			else {
				break;
			}
		}
		for(int i = 1; i < memory_size; i++){ // [x, y] for bucket from (x, y]
			int key = binary_search(i*index.bucket_size, (i+1)*index.bucket_size -1, y);
			if (key != i*index.bucket_size - 1) {
				duration_pairs.push_back(make_pair (i*index.bucket_size, key));
				number_results += key - i*index.bucket_size + 1;
			}
		}
	}
	else{
		for(int i = 0; i < memory_size; i++){ // [x, y] for bucket from (x, y]
			int key = binary_search(i*index.bucket_size, (i+1)*index.bucket_size -1, y);
			if (key != i*index.bucket_size - 1) {
				duration_pairs.push_back(make_pair (i*index.bucket_size, key));
				number_results += key - i*index.bucket_size + 1;
			}
		}
	}
}

int Partial_Load_Covering_Snapshot::binary_search(int begin, int end, int key) {
	// Find the index p, where candidates[p] <= key < candidates[p+1];
	// This is for Covering graph, duration is [begin, p]
	int mid;
	if(end - begin == 1) {
		if (candidates[begin].te > key)
			return begin - 1;
		else if (candidates[end].te <= key)
			return end;
		else
			return begin;
	}
	else {
		mid = (end - begin)/2 + begin;
	}
	if (candidates[mid].te > key)
		return binary_search(begin, mid, key);
	else
		return binary_search(mid, end, key);
}

void Partial_Load_Covering_Snapshot::retrieve_results(){
	results.resize(number_results);
	int count = 0;
	for(int i = 0; i < duration_pairs.size(); i++){
		for(int j = duration_pairs[i].first; j <= duration_pairs[i].second; j++){
			results[count] = candidates[j];
			count++;
		}
	}
}

#endif /* PARTIAL_LOAD_COVERING_SNAPSHOT_HPP_ */
