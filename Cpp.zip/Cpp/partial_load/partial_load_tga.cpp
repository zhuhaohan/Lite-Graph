/*
 * partial_load_tga.cpp
 *
 *  Created on: Oct 30, 2014
 *      Author: zhu
 */

#include "timer.hpp"
#include "index.hpp"
#include "partial_load_covering_snapshot.hpp"
#include "covering_snapshot.hpp"
#include <string>
#include <boost/lexical_cast.hpp>

using namespace std;

int main(){

    int FL_time_array[] = {394563, 1643905, 2883713, 4134935, 5345876, 6543791, 7665540, 8791575, 9707029, 10608420, 11493442};
    int NF_time_array[] = {32004043, 122248287, 131242146, 136468377, 150778804, 156492861, 166278703, 176471905, 195747318, 203198733, 211273538};
    int AS_time_array[] = {248,1442, 2360, 3115, 3660, 4119, 4543, 4843, 5103, 5353, 5533};
    int CPN_time_array[] = {2, 75, 149, 223, 297, 369, 443, 515, 587, 617, 717};
    int CP_time_array[] = {0, 73, 147, 221, 295, 367, 441, 513, 585, 615, 715};
    int TA_time_array[] = {21168000, 39997627, 69002340, 83989380, 99258312, 113601360, 128569680, 142647060, 157772520, 172192393, 187568220};

    int start = NF_time_array[0];
    int end = NF_time_array[10];
    int E = 1500000000;// FL 120000000; TA 800000000; NF 1500000000; AS 5000000; CP 200000000;
    int B = 100000;

    const char* index_file = "/research/datasets/TGA/zhu/NF/NF_INDEX_100K";
    const char* data_file = "/research/datasets/TGA/zhu/NF/NF_PO_100K_B";

    Timer build_index_timer;
    build_index_timer.start();
    Index index(index_file, B, E);
    build_index_timer.stop();
    cout << "Building Bucket Index:\t" << build_index_timer.elapsed_time() << "\t seconds" << endl;

	Timer search_bucket_timer;
	search_bucket_timer.start();
	Covering_Snapshot snapshot(data_file, index, start, end);
	search_bucket_timer.stop();

	cout << "Loading Buckets:\t" << search_bucket_timer.elapsed_time() << "  \t seconds" << endl;
	int s = snapshot.candidates.size();
	cout << "# candidates:\t" << s << endl;
	cout << "# buckets:\t" << snapshot.B << endl;

	Timer retrieve_edge_timer;
	retrieve_edge_timer.start();
	snapshot.get_duration_pairs();
	retrieve_edge_timer.stop();
	cout << "Identifying Edges: \t" << retrieve_edge_timer.elapsed_time() << " \t seconds" << endl;

    int memory_size = 1;
    int memory_size_array[] = {16,32,64,128,256,512,1024,2048,4096,8192,16384};
    //16M, 32M, 64M, 128M, 256M, 512M, 1G, 2G, 4G, 8G, 16G
    double plcount_array[] = {0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0};
    double count = 0.0;

    	for(int j = 0; j <= 10; j++) {

    		memory_size = memory_size_array[j];
    		Partial_Load_Covering_Snapshot pl_snapshot(data_file, index, start, end, memory_size);
    		Timer partial_load_timer;
    		partial_load_timer.start();
    		for(int i = 0; i < pl_snapshot.B; i+=memory_size) {
    			pl_snapshot.load(i);
    			if(i + memory_size < pl_snapshot.B)
    				pl_snapshot.get_duration_pairs(i, memory_size);
    			else
    				pl_snapshot.get_duration_pairs(i, pl_snapshot.B - i);
    		}
    		partial_load_timer.stop();
    		cout << memory_size_array[j] << "\t" << partial_load_timer.elapsed_time() << endl;
    	}
    return 0;
}
