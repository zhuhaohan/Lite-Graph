/*
 * tsssp_tga.cpp
 *
 *  Created on: Oct 30, 2014
 *      Author: zhu
 */

#include "timer.hpp"
#include "index.hpp"
#include "covering_snapshot.hpp"
#include "tsssp.hpp"
#include <string>
#include <boost/lexical_cast.hpp>

using namespace std;

int main(){

    int start;
    int end;
    int FL_time_array[] = {394563, 1643905, 2883713, 4134935, 5345876, 6543791, 7665540, 8791575, 9707029, 10608420, 11493442};
    int NF_time_array[] = {32004043, 122248287, 131242146, 136468377, 150778804, 156492861, 166278703, 176471905, 195747318, 203198733, 211273538};
    int AS_time_array[] = {248,1442, 2360, 3115, 3660, 4119, 4543, 4843, 5103, 5353, 5533};
    int CPN_time_array[] = {2, 75, 149, 223, 297, 369, 443, 515, 587, 617, 717};
    int CP_time_array[] = {0, 73, 147, 221, 295, 367, 441, 513, 585, 615, 715};
    int TA_time_array[] = {21168000, 39997627, 69002340, 83989380, 99258312, 113601360, 128569680, 142647060, 157772520, 172192393, 187568220};

    for(int i = 0; i < 10; i++) {
		start = CP_time_array[i];
		end = CP_time_array[i+1];
		cout << "i = " << i << endl;

    //FL 11179999; TA 168313451; NF 181291836; AS 5476; CP 729;
    int E = 200000000; // FL 120000000; TA 800000000; NF 1500000000; AS 5000000; CP 200000000;
    int V = 1667; // FL 3361; TA 3999979; NF 75315692; AS 393392; CP 1667;
    int B = 5000;

    const char* index_file = "/research/datasets/TGA/zhu/CP/CP_INDEX_5K";
    const char* data_file = "/research/datasets/TGA/zhu/CP/CP_PO_5K_B";
    int src = rand() % V;
    src = 392; //NF 8920; TA 2363327; FL 2922; AS 8447; CP 931 or 531
    
    Timer build_index_timer;
    build_index_timer.start();
    Index index(index_file, B, E);
    build_index_timer.stop();
    //cout << "Building Bucket Index:\t" << build_index_timer.elapsed_time() << "\t seconds" << endl;

    Timer search_bucket_timer;
    search_bucket_timer.start();
    Covering_Snapshot snapshot(data_file, index, start, end);
    search_bucket_timer.stop();
    //cout << "Loading Buckets:\t" << search_bucket_timer.elapsed_time() << "  \t seconds" << endl;

    Timer retrieve_edge_timer;
    retrieve_edge_timer.start();
    snapshot.get_duration_pairs();
    retrieve_edge_timer.stop();
    //cout << "Identifying Edges: \t" << retrieve_edge_timer.elapsed_time() << " \t seconds" << endl;

    Timer retrieve_result_timer;
    retrieve_result_timer.start();
    snapshot.retrieve_results();
    retrieve_result_timer.stop();
    //cout << "Retrieve Output: \t" << retrieve_result_timer.elapsed_time() << " \t seconds" << endl;

    //cout << "# candidates:\t" << snapshot.index_max - snapshot.index_min << endl;
    //cout << "# results:\t" << snapshot.number_results << endl;
    //cout << "# src query:\t" << src << endl;
    for(int cores = 1; cores < 32; cores = cores*2) {
    Timer initial_tsssp_timer;
    initial_tsssp_timer.start();
    TSSSP tsssp(V);
    tsssp.initialization(src, start, end);
    initial_tsssp_timer.stop();
    //cout << "Initializing TSSSP: \t" << initial_tsssp_timer.elapsed_time() << " \t seconds" << endl;

    Timer execute_tsssp_array_timer;
    execute_tsssp_array_timer.start();
    int y = tsssp.execution_es(snapshot.results, cores);
    execute_tsssp_array_timer.stop();
    //cout << "Executing TSSSP: \t" << execute_tsssp_array_timer.elapsed_time() << " \t seconds \t on " << y << " loops" << endl;
    //cout << execute_tsssp_array_timer.elapsed_time() << "\t" << y << endl;
    cout << y << endl;
    //cout << "# Updates:\t" << tsssp.number_updates << endl;
    }
}
    return 0;
}



