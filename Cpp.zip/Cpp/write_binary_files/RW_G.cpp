/*
 * RW_G.cpp
 *
 *  Created on: Sep 15, 2014
 *      Author: zhu
 */

#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

struct Edge
{
    int u, v, ts, te;
    bool operator < (const Edge that) const {
        if (ts != that.ts)
            return ts < that.ts;
        if (te != that.te)
            return te > that.te;
        if (u != that.u)
            return u < that.u;
        else
            return v < that.v;
    }
};

int main(){

    const char* READ_FILE = "/research/datasets/TGA/zhu/CP/CP_PO_0K";
    const char* WRITE_FILE = "/research/datasets/TGA/zhu/CP/CP_PO_0K_B";

    FILE* origin_file = fopen(READ_FILE,"r");
    ofstream binary_file (WRITE_FILE, ios::out | ios::binary);

    int E = 200000000;//120M
    int x;
    Edge e;

    for(int i = 0; i < E; i ++) {
    	x=fscanf(origin_file, "%d %d %d %d",&e.u, &e.v, &e.ts, &e.te);
        binary_file.write((char*)&e, sizeof(struct Edge));
    }
    fclose(origin_file);
    binary_file.close();

    return 0;
}

