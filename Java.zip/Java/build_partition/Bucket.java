/**
 * @author Haohan Zhu
 */

public class Bucket {
    public int min;
    public int max;
    public int index_of_array;
    public int min_overlap;
    public int max_overlap;

    public Bucket(int min, int max, int index_of_array){
        this.min = min;
        this.max = max;
        this.index_of_array = index_of_array;
        this.min_overlap = 0;
        this.max_overlap = 0;
    }
    
    public void set_min_overlap(boolean min_overlap_boolean){
        if(min_overlap_boolean)
            this.min_overlap = 1;
        else
            this.min_overlap = 0;
    }
    
    public void set_max_overlap(boolean max_overlap_boolean){
        if(max_overlap_boolean)
            this.max_overlap = 1;
        else
            this.max_overlap = 0;
    }   
}