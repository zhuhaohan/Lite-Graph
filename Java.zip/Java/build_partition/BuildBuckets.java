/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

public class BuildBuckets {
public static void main(String[] args) {
		
        String FILE_NAME;
        int B;
        if(args.length != 2){
            //FILE_NAME = "/scratch/zhu/TGA/datasets/AS_5M";
        	//FILE_NAME = "/scratch/zhu/TGA/datasets/Cell_750M";
        	FILE_NAME = "/scratch/zhu/TGA/datasets/NF_1.5B";
        	//FILE_NAME = "/scratch/zhu/TGA/datasets/Fligtht_120M";
        	//FILE_NAME = "/scratch/zhu/TGA/datasets/Taxi-100_160M";
            //FILE_NAME = "/scratch/zhu/TGA/datasets/Taxi-500_160M";
        	//FILE_NAME = "/scratch/zhu/TGA/datasets/Taxi-2000_160M";
        	B = 100000;
        }
        else{
            FILE_NAME = args[0];
            B = Integer.parseInt(args[1]);
        }
        
        String WRITE_INDEX_NAME = FILE_NAME + "_I_" + (B/1000) + "K";

        int edges = 1500000000;
        int bucketSize = edges/B;
        
        int level = 31 - Integer.numberOfLeadingZeros(B) + 1;
        int root = (int)Math.pow(2, level-1);
        System.out.println("Total Bucket:\t" + B);
        System.out.println("Total Level:\t" + level);
        System.out.println("Root Bucket:\t" + root);
        
        ArrayList<Bucket> bucketArray = new ArrayList<Bucket>();
        
        String strLine;
        int counter;
        int minSTime, maxSTime, beginIndex;
        
        try{
            FileReader fstreamin = new FileReader(FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            
            for(int i = 0; i < B; i++){
                counter = 0;
                minSTime = 999999999;
                maxSTime = 0;
                
                while ((strLine = in.readLine()) != null) {
                    String[] values = strLine.split("\t");
                    int stime = Integer.parseInt(values[2]);

                    counter++;
                    if(counter == 1)
                        minSTime = stime;   
                    if(counter == bucketSize){
                        maxSTime = stime;
                        break;
                    }
                }
                beginIndex = i*bucketSize;
                bucketArray.add(new Bucket(minSTime, maxSTime, beginIndex));               
            }
            in.close();
            
            bucketArray.get(0).set_min_overlap(false);
            bucketArray.get(0).set_max_overlap(bucketArray.get(0).max==bucketArray.get(0).min);
            for(int  i = 1; i < bucketArray.size()-1; i++) {
                bucketArray.get(i).set_min_overlap(bucketArray.get(i).min == bucketArray.get(i-1).max);
                bucketArray.get(i).set_max_overlap(bucketArray.get(i+1).min == bucketArray.get(i).max);
            }
            bucketArray.get(bucketArray.size()-1).set_min_overlap(bucketArray.get(bucketArray.size()-2).max==bucketArray.get(bucketArray.size()-1).min);
            bucketArray.get(bucketArray.size()-1).set_max_overlap(false);
            
            int number = 1;
            ArrayList<Integer> indexArray = new ArrayList<Integer>(); 
            for(int i = 1; i <= level; i++){
                for(int j = 1; j <= number*2; j=j+2){
                    if(root*j <= B)
                        indexArray.add(root*j);
                }
                root = root / 2;
                number = number * 2;
            }
            
            FileWriter fstreamoutIndexSort = new FileWriter(WRITE_INDEX_NAME);
            BufferedWriter outIndexSort = new BufferedWriter(fstreamoutIndexSort);
            
            for(int i = 0; i < indexArray.size(); i++){
                int index = indexArray.get(i);
                Bucket b = bucketArray.get(index-1);
                outIndexSort.write(b.min + "\t" + b.max + "\t" + b.index_of_array + "\t" + b.min_overlap + "\t" + b.max_overlap + "\n");
            }
            outIndexSort.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
	}
}