/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.PriorityQueue;


public class Partition {

	public static void main(String[] args) {
		
        String FOLDER_NAME  = "/scratch/zhu/";
        String DATASETS_NAME = "datasets/";
        String DATA_NAME;
        int B;
        if(args.length == 1) {
        	B = Integer.parseInt(args[0]);
        	DATA_NAME = "TA";
        }
        else if(args.length == 2){
        	DATA_NAME = args[0];
            B = Integer.parseInt(args[1]);
        }
        else{
        	//DATA_NAME = "FL";
            //DATA_NAME = "AS";
        	//DATA_NAME = "CP";
        	//DATA_NAME = "NF";
        	DATA_NAME = "TA";
        	B = 100000;
        }
        
        String READ_FILE_NAME = FOLDER_NAME + DATASETS_NAME + DATA_NAME + "_TO";
        String WRITE_FILE_NAME = FOLDER_NAME + DATA_NAME + "/" + DATA_NAME + "_PO_" + (B/1000) + "K";
        String WRITE_INDEX_NAME = FOLDER_NAME + DATA_NAME + "/" + DATA_NAME + "_INDEX_" + (B/1000) + "K";

        int edges = 800000000;
        int bucketSize = edges/B;

        int level = 31 - Integer.numberOfLeadingZeros(B) + 1;
        int root = (int)Math.pow(2, level-1);
        System.out.println("# Buckets:\t" + B);
        System.out.println("# Levels:\t" + level);
        System.out.println("Root Bucket Number:\t" + root);
        System.out.println("Bucket Size:\t" + bucketSize);
        
        PriorityQueue<TG> bucketQueue = new PriorityQueue<TG>();
        ArrayList<Bucket> bucketArray = new ArrayList<Bucket>();
        
        String strLine;
        int counter;
        int minSTime, maxSTime, beginIndex;
        
        try{
            FileReader fstreamin = new FileReader(READ_FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            
            for(int i = 0; i < B; i++){
            	bucketQueue.clear();
            	counter = 0;
                minSTime = 999999999;
                maxSTime = 0;
                while ((strLine = in.readLine()) != null) {
                    String[] values = strLine.split("\t");
                    int src = Integer.parseInt(values[0]);
                    int dst = Integer.parseInt(values[1]);
                    int stime = Integer.parseInt(values[2]);
                    int etime = Integer.parseInt(values[3]);
                    bucketQueue.add(new TG(src,dst,stime,etime));
                    counter++;                     
                    if(counter == 1)
                        minSTime = stime;   
                    if(counter == bucketSize){
                        maxSTime = stime;
                        break;
                    }
                }
                beginIndex = i*bucketSize;
                bucketArray.add(new Bucket(minSTime, maxSTime, beginIndex));
                FileWriter fstreamoutO = new FileWriter(WRITE_FILE_NAME, true);
                BufferedWriter outO = new BufferedWriter(fstreamoutO);
                while(!bucketQueue.isEmpty()){
                	TG n = bucketQueue.poll();
                    outO.write(n.src + "\t" + n.dst + "\t" + n.stime+ "\t" + n.etime + "\n");
                }
                outO.close();    
            }
            in.close();
            
            bucketArray.get(0).set_min_overlap(false);
            bucketArray.get(0).set_max_overlap(bucketArray.get(0).max==bucketArray.get(0).min);
            for(int  i = 1; i < bucketArray.size()-1; i++) {
                bucketArray.get(i).set_min_overlap(bucketArray.get(i).min == bucketArray.get(i-1).max);
                bucketArray.get(i).set_max_overlap(bucketArray.get(i+1).min == bucketArray.get(i).max);
            }
            bucketArray.get(bucketArray.size()-1).set_min_overlap(bucketArray.get(bucketArray.size()-2).max==bucketArray.get(bucketArray.size()-1).min);
            bucketArray.get(bucketArray.size()-1).set_max_overlap(false);
            
            int number = 1;
            ArrayList<Integer> indexArray = new ArrayList<Integer>(); 
            for(int i = 1; i <= level; i++){
                for(int j = 1; j <= number*2; j=j+2){
                    if(root*j <= B)
                        indexArray.add(root*j);
                }
                root = root / 2;
                number = number * 2;
            }
            
            FileWriter fstreamoutIndexSort = new FileWriter(WRITE_INDEX_NAME);
            BufferedWriter outIndexSort = new BufferedWriter(fstreamoutIndexSort);
            
            for(int i = 0; i < indexArray.size(); i++){
                int index = indexArray.get(i);
                Bucket b = bucketArray.get(index-1);
                outIndexSort.write(b.min + "\t" + b.max + "\t" + b.index_of_array + "\t" + b.min_overlap + "\t" + b.max_overlap + "\n");
            }
            outIndexSort.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
	}
}
