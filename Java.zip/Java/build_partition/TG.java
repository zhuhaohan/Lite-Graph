/**
 * @author Haohan Zhu
 */

public class TG implements Comparable<TG>{  
    public int src;
    public int dst;
    public int stime;
    public int etime;
        
    public TG(int src, int dst, int stime, int etime){
        this.src = src;
        this.dst = dst;
        this.stime = stime;
        this.etime = etime;
    }

    @Override
    public int compareTo(TG other){
        return new Integer(this.etime).compareTo(other.etime);
    }
}