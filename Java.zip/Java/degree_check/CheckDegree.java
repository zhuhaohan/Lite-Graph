/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.PriorityQueue;

public class CheckDegree {

	public static void main(String[] args) {
		
        String FILE_NAME;
        if(args.length != 1){
            //FILE_NAME = "/research/datasets/TGA/zhu/datasets/AS";
        	//FILE_NAME = "/research/datasets/TGA/zhu/datasets/CP";
        	FILE_NAME = "/research/datasets/TGA/zhu/datasets/FL";
        	//FILE_NAME = "/research/datasets/TGA/zhu/datasets/NF";
        	//FILE_NAME = "/research/datasets/TGA/zhu/datasets/TA";
        }
        else{
            FILE_NAME = args[0];
        }
        
        String READ_FILE_NAME = FILE_NAME + "_NCMV";
        String WRITE_FILE_NAME = FILE_NAME + "_Degree.txt";
        
        try{
            FileReader fstreamin = new FileReader(READ_FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
            PriorityQueue<Pair> degreeQueue = new PriorityQueue<Pair>();
            
            while ((strLine = in.readLine()) != null) {
            	String[] values = strLine.split(":");
            	int node_id = Integer.parseInt(values[0]);
            	String[] neighbors = values[1].split(",");
            	int degree = neighbors.length;
                
            	degreeQueue.add(new Pair(degree, node_id));
            }
            in.close();
            
            FileWriter fstreamout = new FileWriter(WRITE_FILE_NAME);
            BufferedWriter out = new BufferedWriter(fstreamout);
            
            while(!degreeQueue.isEmpty()){
            	Pair p = degreeQueue.poll();
            	out.write(p.key + "\t" + p.value + "\n");
            }
            out.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
	}
}
