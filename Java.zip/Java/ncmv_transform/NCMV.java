/**
 * @author Haohan Zhu
 */

public class NCMV implements Comparable<NCMV>{
    public int dst;
    public int stime;
    public int etime;

    public NCMV(int dst, int stime, int etime){
        this.dst = dst;
        this.stime = stime;
        this.etime = etime;
    }
    
	@Override
    public int compareTo(NCMV other){
		if(this.stime != other.stime)
			return new Integer(this.stime).compareTo(other.stime);
		else
			return new Integer(this.dst).compareTo(other.dst);
	}
}