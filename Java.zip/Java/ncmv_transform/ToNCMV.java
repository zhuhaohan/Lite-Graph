/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.PriorityQueue;

public class ToNCMV {

	public static void main(String[] args) {
		
        String FILE_NAME;
        if(args.length != 1){
            //FILE_NAME = "/scratch/zhu/datasets/AS";
        	//FILE_NAME = "/scratch/zhu/datasets/CP";
        	//FILE_NAME = "/scratch/zhu/datasets/FL";
        	//FILE_NAME = "/scratch/zhu/datasets/NF";
        	FILE_NAME = "/scratch/zhu/datasets/TA";
        }
        else{
            FILE_NAME = args[0];
        }
        
        String READ_FILE_NAME = FILE_NAME + "_TO";
        String WRITE_FILE_NAME = FILE_NAME + "_NCMV";
        
        try{
            FileReader fstreamin = new FileReader(READ_FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
            HashMap<Integer, PriorityQueue<NCMV>> edgeMap = new HashMap<Integer, PriorityQueue<NCMV>>();
            
            while ((strLine = in.readLine()) != null) {
            	String[] values = strLine.split("\t");
            	int src = Integer.parseInt(values[0]);
            	int dst = Integer.parseInt(values[1]);
            	int stime = Integer.parseInt(values[2]);
            	int etime = Integer.parseInt(values[3]);
                
            	if(edgeMap.keySet().contains(src)){
                	edgeMap.get(src).add(new NCMV(dst, stime, etime));
                }
                else{
                	edgeMap.put(src, new PriorityQueue<NCMV>());
                	edgeMap.get(src).add(new NCMV(dst, stime, etime));
                }
            }
            in.close();
            
            FileWriter fstreamout = new FileWriter(WRITE_FILE_NAME, true);
            BufferedWriter out = new BufferedWriter(fstreamout);
            
            for(Integer key : edgeMap.keySet()){
            	out.write(key + ":");
                while(!edgeMap.get(key).isEmpty()){
                	NCMV p = edgeMap.get(key).poll();
                    out.write(p.dst + "," + p.stime + "," + p.etime + "\t");
                }
                out.write("\n");
            }
            out.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
	}
}
