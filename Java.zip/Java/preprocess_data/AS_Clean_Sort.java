/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;


public class AS_Clean_Sort {
	
	public static void main(String[] args) { 
        
		File folder;
        File[] fileList;
        String WRITE_FILE_NAME = "/research/datasets/AS_UCLA/ordered-new-ipv4";
    
        if(args.length != 1){
	    	folder = new File("/research/datasets/AS_UCLA/ipv4/daily");
		}
        else{
            folder = new File(args[0]);    
        }

        if(folder.isDirectory()) {
            fileList = folder.listFiles();
            Arrays.sort(fileList);

            HashSet<Integer> nodeSet = new HashSet<Integer>();
            int number_of_edges = 0;
            String file_name = "";
            int current_date = 0;
            HashMap<Integer,HashMap<Integer,TimePair>>  edgeMap = new HashMap<Integer,HashMap<Integer,TimePair>>();
            PriorityQueue<AS> asQueue = new PriorityQueue<AS>();
            
            for(File file:fileList){
                try{
                	file_name = file.getName();
                	//current_date = Integer.parseInt(file_name.substring(0, 8));
                	current_date = DayOfYear(file_name.substring(0, 8));
                	
                	FileReader fstreamin = new FileReader(folder + "/" + file_name);
                	BufferedReader in = new BufferedReader(fstreamin);
                	String strLine; // Get the header

                	//Read File Line By Line
                	while ((strLine = in.readLine()) != null) {
                		String[] values = strLine.split("\t");
                		int src = Integer.parseInt(values[0]);
                		int dst = Integer.parseInt(values[1]);
                    
                		nodeSet.add(src);
                		nodeSet.add(dst);
                		number_of_edges++;
                		
                		if(!edgeMap.containsKey(src)) {
                			edgeMap.put(src, new HashMap<Integer,TimePair>());
                			edgeMap.get(src).put(dst, new TimePair(current_date));
                		}
                		else {
                			if (!edgeMap.get(src).containsKey(dst)) {
                				edgeMap.get(src).put(dst, new TimePair(current_date));
                			}
                			else {
                				if(edgeMap.get(src).get(dst).getStart() != 0) {
                					edgeMap.get(src).get(dst).setEnd(current_date);
                				}
                				else {
                					edgeMap.get(src).get(dst).setStart(current_date);
                					edgeMap.get(src).get(dst).setEnd(current_date);
                				}
                			}
                		}
                	}
                	in.close();

                	for(int src_key : edgeMap.keySet()){
                		for(int dst_key : edgeMap.get(src_key).keySet()) {
                    		if(edgeMap.get(src_key).get(dst_key).getEnd() < current_date && edgeMap.get(src_key).get(dst_key).getEnd() > 0) {
                    			int start = edgeMap.get(src_key).get(dst_key).getStart();
                    			int end = edgeMap.get(src_key).get(dst_key).getEnd();
                    			asQueue.add(new AS(src_key, dst_key, start, end));
                    			edgeMap.get(src_key).get(dst_key).setStart(0);
                    			edgeMap.get(src_key).get(dst_key).setEnd(0);
                    		}
                		}
                	}
                }
                catch (Exception e){
                	System.err.println("Error: " + e.getMessage());
                	System.err.println(e.toString());
            	}
            }
            
        	for(int src_key : edgeMap.keySet()){
        		for(int dst_key : edgeMap.get(src_key).keySet()) {
            		if(edgeMap.get(src_key).get(dst_key).getEnd() > 0) {
            			int start = edgeMap.get(src_key).get(dst_key).getStart();
            			int end = edgeMap.get(src_key).get(dst_key).getEnd();
            			asQueue.add(new AS(src_key, dst_key, start, end));
            			edgeMap.get(src_key).get(dst_key).setStart(0);
            			edgeMap.get(src_key).get(dst_key).setEnd(0);
            		}
        		}
        	}
            
            System.out.println("# nodes:\t" + nodeSet.size());
            System.out.println("# edges:\t" + number_of_edges);
            System.out.println("# duration edges:\t" + asQueue.size());
            
            try{
            	FileWriter fstreamout  = new FileWriter(WRITE_FILE_NAME);
            	BufferedWriter out = new BufferedWriter(fstreamout);
            	while(!asQueue.isEmpty()) {
            		AS as = asQueue.poll();
            		out.write(as.src + "\t" + as.dst + "\t" + as.stime + "\t" + as.etime + "\t" + as.duration + "\n");
            		//out.write(as.src + "\t" + as.dst + "\t" + as.stime + "\t" + as.etime + "\n");
            	}
            	out.close();
            }
            catch (Exception e){
            	System.err.println("Error: " + e.getMessage());
            	System.err.println(e.toString());
        	}
        }
	}
	
	public static int DayOfYear(String YearMonthDay) {
		int DayFrom19990101 = 0;
		int year = Integer.parseInt(YearMonthDay.substring(0, 4));
		int month = Integer.parseInt(YearMonthDay.substring(4, 6));
		int day = Integer.parseInt(YearMonthDay.substring(6, 8));
		if (year == 2000)
			DayFrom19990101 += 365;
		else if (year == 2001)
			DayFrom19990101 += 365 + 366;
		else if (year == 2002)
			DayFrom19990101 += 365 + 366 + 365;
		else if (year == 2003)
			DayFrom19990101 += 365 + 366 + 365 + 365;
		else if (year == 2004)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365;
		else if (year == 2005)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366;
		else if (year == 2006)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365;
		else if (year == 2007)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365;
		else if (year == 2008)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365;
		else if (year == 2009)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365 + 366;
		else if (year == 2010)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365 + 366 + 365;
		else if (year == 2011)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365;
		else if (year == 2012)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365;
		else if (year == 2013)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365 + 366;
		else if (year == 2014)
			DayFrom19990101 += 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365 + 366 + 365 + 365 + 365 + 366 + 365 ;
		
		if(year%4!=0){
			if (month == 2)
				DayFrom19990101 += 31;
			else if (month == 3)
				DayFrom19990101 += 31 + 28;
			else if (month == 4)
				DayFrom19990101 += 31 + 28 + 31;
			else if (month == 5)
				DayFrom19990101 += 31 + 28 + 31 + 30;
			else if (month == 6)
				DayFrom19990101 += 31 + 28 + 31 + 30 + 31;
			else if (month == 7)
				DayFrom19990101 += 31 + 28 + 31 + 30 + 31 + 30;
			else if (month == 8)
				DayFrom19990101 += 31 + 28 + 31 + 30 + 31 + 30 + 31;
			else if (month == 9)
				DayFrom19990101 += 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31;
			else if (month == 10)
				DayFrom19990101 += 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30;
			else if (month == 11)
				DayFrom19990101 += 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31;
			else if (month == 12)
				DayFrom19990101 += 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30;
		}
		else{
			if (month == 2)
				DayFrom19990101 += 31;
			else if (month == 3)
				DayFrom19990101 += 31 + 29;
			else if (month == 4)
				DayFrom19990101 += 31 + 29 + 31;
			else if (month == 5)
				DayFrom19990101 += 31 + 29 + 31 + 30;
			else if (month == 6)
				DayFrom19990101 += 31 + 29 + 31 + 30 + 31;
			else if (month == 7)
				DayFrom19990101 += 31 + 29 + 31 + 30 + 31 + 30;
			else if (month == 8)
				DayFrom19990101 += 31 + 29 + 31 + 30 + 31 + 30 + 31;
			else if (month == 9)
				DayFrom19990101 += 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31;
			else if (month == 10)
				DayFrom19990101 += 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30;
			else if (month == 11)
				DayFrom19990101 += 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31;
			else if (month == 12)
				DayFrom19990101 += 31 + 29 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30;
		}
		
		DayFrom19990101 += (day-1);
		return DayFrom19990101;
	}
}