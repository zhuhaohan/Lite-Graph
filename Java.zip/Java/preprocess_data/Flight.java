public class Flight implements Comparable<Flight>{  
	public int src;
	public int dst;
	public int stime;
	public int etime;
	public int duration;
	
	public Flight (int src, int dst, int stime, int etime, int duration) {
		this.src = src;
		this.dst = dst;
		this.stime = stime;
		this.etime = etime;
		this.duration = duration;
	}	
        
	@Override
    public int compareTo(Flight other){
		if(this.stime != other.stime)
			return new Integer(this.stime).compareTo(other.stime);
		else if(this.etime != other.etime)
			return new Integer(this.etime).compareTo(other.etime);
		else if(this.src != other.src)
			return new Integer(this.src).compareTo(other.src);
		else
			return new Integer(this.dst).compareTo(other.dst);
    }
}