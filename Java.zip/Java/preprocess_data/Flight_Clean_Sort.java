/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.PriorityQueue;


public class Flight_Clean_Sort {
	
	public static void main(String[] args) { 
        String READ_FOLDER_NAME = "/research/datasets/Flight/original_data/";
        String WRITE_FOLDER_NAME = "/research/datasets/Flight/TGA_new/";

        String READ_NODE_NAME = READ_FOLDER_NAME + "airports.csv";
        HashMap<String, Integer> nodeMap = getNode(READ_NODE_NAME);
        
        for(int i = 1987; i <= 2008; i++){
        	String READ_FILE_NAME = READ_FOLDER_NAME + i + ".csv";
            PriorityQueue<Flight> edgeQueue = new PriorityQueue<Flight>();
        	try {
        		FileReader fstreamin = new FileReader(READ_FILE_NAME);
        		BufferedReader in = new BufferedReader(fstreamin);
        		String strLine = in.readLine(); // Get the header
        		//Read File Line By Line
                while ((strLine = in.readLine()) != null)   {
                    String[] values = strLine.split(",");
                    if(values.length != 29){//If the record is corrupted, discard it
                    	continue;
                    }
                    if(values[0].equals("NA") || values[1].equals("NA") || values[2].equals("NA")
                   		 || values[4].equals("NA") || values[6].equals("NA") || values[11].equals("NA")){
                           //If the record missing any essential value, discard it
                           continue;
                    }
                    if(!nodeMap.containsKey(values[16]) || !nodeMap.containsKey(values[17])){
                    	continue;
                    }
                    int Origin = nodeMap.get(values[16]);
                    int Dest = nodeMap.get(values[17]);
                    
                    int Year = Integer.parseInt(values[0]);
                    int Month = Integer.parseInt(values[1]);
                    int DayofMonth = Integer.parseInt(values[2]);
                    int DepTime = Integer.parseInt(values[4]);
                    int ArrTime = Integer.parseInt(values[6]);
                    int ActualElapsedTime = Integer.parseInt(values[11]);
                    
                    edgeQueue.add(getFlight(Year, Month, DayofMonth, DepTime, ArrTime, ActualElapsedTime, Origin, Dest));
                }
                in.close();
                System.out.println("File:\t" + i + ".csv" + "\t # Edges:\t" + edgeQueue.size());
                String WRITE_FILE_NAME = WRITE_FOLDER_NAME + "ordered-" + i;

                FileWriter fstreamout  = new FileWriter(WRITE_FILE_NAME);
                BufferedWriter out = new BufferedWriter(fstreamout);
                while(!edgeQueue.isEmpty()) {
                	Flight f = edgeQueue.poll();
                	out.write(f.src + "\t" + f.dst + "\t" + f.stime + "\t" + f.etime + "\t" + f.duration + "\n");
                	//out.write(f.src + "\t" + f.dst + "\t" + f.stime + "\t" + f.etime + "\n");
                }
                out.close();
            }
            catch (Exception e){
                System.err.println("Error: " + e.getMessage());
            }
            System.out.println("File:\t" + "ordered-" + i + "\t Written");
        }
	}
	
	public static HashMap<String, Integer> getNode(String FILE_NAME) {
		HashMap<String, Integer> nodeMap = new HashMap<String, Integer>();
		int nodeCounter = 0;
		try {
			FileReader fstreamin = new FileReader(FILE_NAME);
			BufferedReader in = new BufferedReader(fstreamin);
			String strLine = in.readLine(); // Get the header
            while ((strLine = in.readLine()) != null)   {
                String[] values = strLine.split(",");
                String IATA = values[0].substring(1, values[0].length()-1);
                if(!nodeMap.containsKey(IATA)){
                	nodeCounter++;
                	nodeMap.put(IATA, nodeCounter);
                }
            }
            in.close();
		}
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
        System.out.println("# Nodes:\t" + nodeCounter);
        return nodeMap;
	}
	
	public static Flight getFlight(int Year, int Month, int DayofMonth, int DepTime, int ArrTime, int ActualElapsedTime, int Origin, int Dest) {
        int stime = getTime(Year, Month, DayofMonth, DepTime);
        int etime = getTime(Year, Month, DayofMonth, ArrTime);
        while (etime < stime){
        	etime += 24*60;
        }
		int duration = ActualElapsedTime;
        if (duration > (etime - stime))
        	duration = etime - stime;
		Flight f = new Flight(Origin, Dest, stime, etime, duration);
		return f;
	}
	
	public static int getTime(int Year, int Month, int DayofMonth, int Time) {
        int day = 0;
		for(int i = 1987; i < Year; i++){
        	if(i%4==0) {
        		day += 366;
        	}
        	else {
        		day += 365;
        	}
        }
		for(int i = 1; i < Month; i++) {
			if(i == 1)
				day += 31;
			else if (i == 2) {
				if(Year%4==0)
					day += 29;
				else
					day += 28;
			}
			else if (i == 3) {
				day += 31;
			}
			else if (i == 4) {
				day += 30;
			}
			else if (i == 5) {
				day += 31;
			}
			else if (i == 6) {
				day += 30;
			}
			else if (i == 7) {
				day += 31;
			}
			else if (i == 8) {
				day += 31;
			}
			else if (i == 9) {
				day += 30;
			}
			else if (i == 10) {
				day += 31;
			}
			else if (i == 11) {
				day += 30;
			}
		}
		day += DayofMonth;
		int currentTime = day*24*60 + Time/100*60 + Time%100;
		return currentTime;
	}	
}

//cat ordered-1987 ordered-1988 ordered-1989 ordered-1990 ordered-1991 ordered-1992 ordered-1993 ordered-1994 ordered-1995 ordered-1996 ordered-1997 ordered-1998 ordered-1999 ordered-2000 ordered-2001 ordered-2002 ordered-2003 ordered-2004 ordered-2005 ordered-2006 ordered-2007 ordered-2008 >> ordered-Flight
