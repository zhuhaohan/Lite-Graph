/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;

//cat SET1V_01.CSV SET1V_02.CSV SET1V_03.CSV SET1V_04.CSV SET1V_05.CSV SET1V_06.CSV SET1V_07.CSV SET1V_08.CSV SET1V_09.CSV SET1V_10.CSV SET1V_11.CSV SET1V_12.CSV >> SET1V.CSV 

public class Orange_Clean_Sort {
	
	public static void main(String[] args) { 
        
        String READ_FILE_NAME = "/research/datasets/Orange/SET1/SET1V.CSV";
        String WRITE_FILE_NAME = "/research/datasets/Orange/SET1/Orange24h";

        int number_of_edges = 0;
        HashSet<Integer> nodeSet = new HashSet<Integer>(); 
        HashSet<Integer> timeSet = new HashSet<Integer>();
        	
        HashMap<Integer,HashMap<Integer,TimePair>>  edgeMap = new HashMap<Integer,HashMap<Integer,TimePair>>();
        PriorityQueue<Orange> orangeQueue = new PriorityQueue<Orange>();
            
        try{
        	FileReader fstreamin = new FileReader(READ_FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;

            while ((strLine = in.readLine()) != null) {
            	String[] values = strLine.split(",");
            	String[] timestamps = values[0].split(" ");
            	String[] Dates = timestamps[0].split("-");
            	int day = DayOfYear(Integer.parseInt(Dates[0]), Integer.parseInt(Dates[1]), Integer.parseInt(Dates[2]));
            	int hour = Integer.parseInt(timestamps[1]);
            	int src = Integer.parseInt(values[1]);
            	int dst = Integer.parseInt(values[2]);

                nodeSet.add(src);
                nodeSet.add(dst);
                
                number_of_edges++;
                
                int currentTime = (day*24 + hour)/24;
                timeSet.add(currentTime);
                
                if(!edgeMap.containsKey(src)) {
                	edgeMap.put(src, new HashMap<Integer,TimePair>());
                	edgeMap.get(src).put(dst, new TimePair(currentTime));
                }
                else {
                	if (!edgeMap.get(src).containsKey(dst)) {
                		edgeMap.get(src).put(dst, new TimePair(currentTime));
                	}
                	else {
                		if (edgeMap.get(src).get(dst).getEnd() == currentTime)
                			;
                		else if (edgeMap.get(src).get(dst).getEnd() + 1 == currentTime)
                			edgeMap.get(src).get(dst).setEnd(currentTime);
                		else {
                			orangeQueue.add(new Orange(src, dst, edgeMap.get(src).get(dst).getStart(), edgeMap.get(src).get(dst).getEnd()));
                			edgeMap.get(src).get(dst).setStart(currentTime);
                			edgeMap.get(src).get(dst).setEnd(currentTime);
                		}
                	}
                }
                
                if(number_of_edges%10000000==0)
                	System.out.println(number_of_edges/10000000 + " *10M edges have been processed");
            }

        	for(int src_key : edgeMap.keySet()){
        		for(int dst_key : edgeMap.get(src_key).keySet()) {
            		int start = edgeMap.get(src_key).get(dst_key).getStart();
            		int end = edgeMap.get(src_key).get(dst_key).getEnd();
            		orangeQueue.add(new Orange(src_key, dst_key, start, end));
        		}
        	}
            in.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
            System.err.println(e.toString());
        }
        
        System.out.println("# Nodes:\t" + nodeSet.size());
        System.out.println("# Edges:\t" + number_of_edges);
        System.out.println("# Time:\t" + timeSet.size());
        System.out.println("# Duration Edges:\t" + orangeQueue.size());
        
        try{
        	FileWriter fstreamout  = new FileWriter(WRITE_FILE_NAME);
        	BufferedWriter out = new BufferedWriter(fstreamout);
        	while(!orangeQueue.isEmpty()) {
        		Orange o = orangeQueue.poll();
        		out.write(o.src + "\t" + o.dst + "\t" + o.stime + "\t" + o.etime + "\t" + o.duration + "\n");
        		//out.write(o.src + "\t" + o.dst + "\t" + o.stime + "\t" + o.etime + "\n");
        	}
        	out.close();
        }
        catch (Exception e){
        	System.err.println("Error: " + e.getMessage());
        	System.err.println(e.toString());
    	}
    }

	public static int DayOfYear(int year, int month, int day) {
		int DayYear = 0;
		if ( year > 2013 )
			DayYear += 2013*365;
		if (month == 2)
			DayYear += 31;
		else if (month == 3)
			DayYear += 31 + 28;
		else if (month == 4)
			DayYear += 31 + 28 + 31;
		else if (month == 5)
			DayYear += 31 + 28 + 31 + 30;
		else if (month == 6)
			DayYear += 31 + 28 + 31 + 30 + 31;
		else if (month == 7)
			DayYear += 31 + 28 + 31 + 30 + 31 + 30;
		else if (month == 8)
			DayYear += 31 + 28 + 31 + 30 + 31 + 30 + 31;
		else if (month == 9)
			DayYear += 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31;
		else if (month == 10)
			DayYear += 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30;
		else if (month == 11)
			DayYear += 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31;
		else if (month == 12)
			DayYear += 31 + 28 + 31 + 30 + 31 + 30 + 31 + 31 + 30 + 31 + 30;	
		DayYear += (day-1);
		return DayYear;
	}
}
