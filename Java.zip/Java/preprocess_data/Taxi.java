public class Taxi implements Comparable<Taxi>{  
	public int src;
	public int dst;
	public int stime;
	public int etime;
	
	public Taxi (int src, int dst, int stime, int etime) {
		this.src = src;
		this.dst = dst;
		this.stime = stime;
		this.etime = etime;
	}
        
	@Override
    public int compareTo(Taxi other){
		if(this.stime != other.stime)
			return new Integer(this.stime).compareTo(other.stime);
		else if(this.etime != other.etime)
			return new Integer(this.etime).compareTo(other.etime);
		else if(this.src != other.src)
			return new Integer(this.src).compareTo(other.src);
		else
			return new Integer(this.dst).compareTo(other.dst);
    }
}
