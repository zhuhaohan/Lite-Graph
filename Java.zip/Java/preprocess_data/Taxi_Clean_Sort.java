/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.PriorityQueue;

public class Taxi_Clean_Sort {
	
	public static void main(String[] args) { 
        String READ_FOLDER_NAME = "/scratch/zhu/TaxiData/";
        String WRITE_FOLDER_NAME = "/scratch/zhu/TaxiData/TGA/";
        
        int year = 2013;
        double min_longitude = -74.04;
        double max_longitude = -73.74;
        double min_latitude = 40.57;
        double max_latitude = 40.87;
        int partition = 2000;
        double longitude_unit = (max_longitude - min_longitude) / partition;
        double latitude_unit = (max_latitude - min_latitude) / partition;
        
        for(int i = 1; i <= 12; i++){
        	String READ_FILE_NAME = READ_FOLDER_NAME + year + "/trip_data_" + i + ".csv";
        	PriorityQueue<Taxi> edgeQueue = new PriorityQueue<Taxi>();
        	int countCorruptedRecords = 0;
        	int countWrongDuration = 0;
        	int countWrongGPS = 0;
        	int countLongDuration = 0;
        	int wrongDate = 0;
        	int minTime = 999999999;
        	String minTimeStr="";
        	int maxTime = 0;
        	String maxTimeStr="";
        	int maxDuration = 0;
        	try {
        		FileReader fstreamin = new FileReader(READ_FILE_NAME);
        		BufferedReader in = new BufferedReader(fstreamin);
        		String strLine = in.readLine(); // Get the header
        		//Read File Line By Line
                while ((strLine = in.readLine()) != null)   {
                    String[] values = strLine.split(",");
                    if(values.length != 18){//If the record is corrupted, discard it
                    	countCorruptedRecords++;
                    	continue;
                    }
                    if(values[1].equals("")
                    		|| values[2].equals("")
                    		|| values[5].equals("")
                    		|| values[6].equals("")
                    		|| values[7].equals("")
                    		|| values[8].equals("")){//If the record is corrupted, discard it
                    	countCorruptedRecords++;
                    	continue;
                    }
                    String start_time_str = values[1];
                    String end_time_str = values[2];
                    int stime = getTime(start_time_str);
                    int etime = getTime(end_time_str);
                    int duration = etime -stime;
                	Double pickup_longitude = Double.parseDouble(values[5]);
                	Double pickup_latitude = Double.parseDouble(values[6]);
                	Double dropoff_longitude = Double.parseDouble(values[7]);
                	Double dropoff_latitude = Double.parseDouble(values[8]);
                	
                    int src_id = (int)((pickup_longitude - min_longitude) / longitude_unit)*partition + (int)((pickup_latitude - min_latitude) / latitude_unit);
                    int dst_id = (int)((dropoff_longitude - min_longitude) / longitude_unit)*partition + (int)((dropoff_latitude - min_latitude) / latitude_unit);

                    /*int upper_bound = getTime(year + "-" + i + "-31 23:59:59");
                    if(stime > upper_bound) {
                    	wrongDate++;
                    	continue;
                    }*/
                    
                    if(duration > 604800){
                    	countLongDuration++;
                    	continue;
                    }
                    
                	if(duration<=0){
                		countWrongDuration++;
                		continue;
                	}
                	
                	if(pickup_longitude < min_longitude
                			|| pickup_longitude > max_longitude
                			|| dropoff_longitude < min_longitude
                			|| dropoff_longitude > max_longitude
                			|| pickup_latitude < min_latitude
                			|| pickup_latitude > max_latitude 
                			|| dropoff_latitude < min_latitude
                			|| dropoff_latitude > max_latitude){
                		countWrongGPS++;
                		continue;
                	}

                    if(stime < minTime) {
                    	minTime = stime;
                    	minTimeStr = start_time_str;
                    }

                    if(stime > maxTime) {
                    	maxTime = stime;
                    	maxTimeStr = start_time_str;
                    }
                    
                    if(duration > maxDuration) {
                    	maxDuration = duration;
                    }
                    
                	edgeQueue.add(new Taxi(src_id, dst_id, stime, etime));
                }
                in.close();
                System.out.println("File:\t" + i + ".csv");
                System.out.println("# Edges:\t" + edgeQueue.size());
                System.out.println("# Corrupted Records:\t" + countCorruptedRecords);
                System.out.println("# Wrong Durations:\t" + countWrongDuration);
                System.out.println("# Long Durations:\t" + countLongDuration);
                System.out.println("# Corrupted GPS:\t" + countWrongGPS);
                System.out.println("# Wrong Date:\t" + wrongDate);
                System.out.println("# Min Time:\t" + minTimeStr + "\t" + minTime);
                System.out.println("# Max Time:\t" + maxTimeStr + "\t" + maxTime);
                System.out.println("# Max Duration:\t" + maxDuration);
                
                String WRITE_FILE_NAME = WRITE_FOLDER_NAME + year + "/ordered-" + i;
                FileWriter fstreamout  = new FileWriter(WRITE_FILE_NAME);
                BufferedWriter out = new BufferedWriter(fstreamout);
                while(!edgeQueue.isEmpty()) {
                	Taxi t = edgeQueue.poll();
                	out.write(t.src + "\t" + t.dst + "\t" + t.stime + "\t" + t.etime + "\n");
                }
                out.close();
            }
            catch (Exception e){
                System.err.println("Error: " + e.getMessage());
            }
        }
	}
	
	public static int getTime(String time_str) {
		int time = 0;
		String[] time_array = time_str.split(" ");
		String[] date_array = time_array[0].split("-");
		int year = Integer.parseInt(date_array[0]);
		int month = Integer.parseInt(date_array[1]);
		int day = Integer.parseInt(date_array[2]);
		String[] second_array = time_array[1].split(":");
		int hour = Integer.parseInt(second_array[0]);
		int minute = Integer.parseInt(second_array[1]);
		int second = Integer.parseInt(second_array[2]);
		
		for(int i = 2008; i < year; i++){
        	if(i%4==0) {
        		time += 366;
        	}
        	else {
        		time += 365;
        	}
        }
		for(int i = 1; i < month; i++) {
			if(i == 1)
				time += 31;
			else if (i == 2) {
				if(year%4==0)
					time += 29;
				else
					time += 28;
			}
			else if (i == 3) {
				time += 31;
			}
			else if (i == 4) {
				time += 30;
			}
			else if (i == 5) {
				time += 31;
			}
			else if (i == 6) {
				time += 30;
			}
			else if (i == 7) {
				time += 31;
			}
			else if (i == 8) {
				time += 31;
			}
			else if (i == 9) {
				time += 30;
			}
			else if (i == 10) {
				time += 31;
			}
			else if (i == 11) {
				time += 30;
			}
		}
		time += day;
		int currentTime = time*24*60*60 + hour*60*60 + minute*60 + second;
		return currentTime;
	}	
}

//cat ordered-1 ordered-2 ordered-3 ordered-4 ordered-5 ordered-6 ordered-7 ordered-8 ordered-9 ordered-10 ordered-11 ordered-12 >> ordered-Taxi
