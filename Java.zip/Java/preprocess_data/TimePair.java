public class TimePair {
	public int start;
	public int end;

	public TimePair(int start) {
		this.start = start;
		this.end = start;
	}
	
	public TimePair(int start, int end) {
		this.start = start;
		this.end = end;
	}

	public int getStart() {
		return this.start;
	}
	
	public int getEnd() {
		return this.end;
	}
	
	public void setStart(int start) {
		this.start = start;
	}
	
	public void setEnd(int end) {
		this.end = end;
	}
}
