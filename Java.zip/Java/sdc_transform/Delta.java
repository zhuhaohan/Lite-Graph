/**
 * @author Haohan Zhu
 */

public class Delta implements Comparable<Delta> {
	public int id;
    public int time;
    public int operation;

    public Delta(int id, int time, int operation){
    	this.id = id;
    	this.time = time;
    	this.operation = operation;
    }
    
	@Override
    public int compareTo(Delta other){
		if(this.time != other.time)
			return new Integer(this.time).compareTo(other.time);
		else if(this.id != other.id)
			return new Integer(this.id).compareTo(other.id);
		else
			return new Integer(this.operation).compareTo(other.operation);
	}
}
