/**
 * @author Haohan Zhu
 */

public class Edge implements Comparable<Edge>{
	public int src;
    public int dst;
    public int stime;
    public int etime;

    public Edge(int src, int dst, int stime, int etime){
        this.src = src;
    	this.dst = dst;
        this.stime = stime;
        this.etime = etime;
    }
    
	@Override
    public int compareTo(Edge other){
		if(this.src != other.src)
			return new Integer(this.src).compareTo(other.src);
		else if(this.dst != other.dst)
			return new Integer(this.dst).compareTo(other.dst);
		else if(this.stime != other.stime)
			return new Integer(this.stime).compareTo(other.stime);
		else
			return new Integer(this.etime).compareTo(other.etime);			
	}
}
