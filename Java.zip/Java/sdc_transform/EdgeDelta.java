/**
 * @author Haohan Zhu
 */

public class EdgeDelta implements Comparable<EdgeDelta> {
	public int src;
	public int dst;
    public int stime;
    public int etime;
    public int operation;

    public EdgeDelta(int src, int dst, int stime, int etime, int operation){
    	this.src = src;
    	this.dst = dst;
    	this.stime = stime;
    	this.etime = etime;
        this.operation = operation;
    }
    
	@Override
    public int compareTo(EdgeDelta other){
		int t1, t2;
		if(this.operation == 0)
			t1 = this.stime;
		else
			t1 = this.etime;
		if(other.operation == 0)
			t2 = other.stime;
		else
			t2 = other.etime;
		if(t1 != t2)
			return new Integer(t1).compareTo(t2);
		else if(this.src != other.src)
			return new Integer(this.src).compareTo(other.src);
		else if(this.dst != other.dst)
			return new Integer(this.dst).compareTo(other.dst);
		else
			return new Integer(this.operation).compareTo(other.operation);
	}
}
