/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.PriorityQueue;

public class ToDelta {

	public static void main(String[] args) {
		
        String FOLDER_NAME  = "/research/datasets/TGA/zhu/";
        String DATA_NAME;
        int interval;
        if(args.length == 1) {
        	DATA_NAME = "FL";
        	interval = Integer.parseInt(args[0]);
        }
        else if(args.length == 2){
        	DATA_NAME = args[0];
        	interval = Integer.parseInt(args[1]);
        }
        else{
        	//DATA_NAME = "NF";
            //DATA_NAME = "AS";
        	//DATA_NAME = "CP";
        	//DATA_NAME = "FL";
        	DATA_NAME = "TA";
        	interval = 100;
        }

        String READ_FILE_NAME = FOLDER_NAME + "TO/" + DATA_NAME + "_TO";
        String WRITE_DELTA_NAME = FOLDER_NAME + "SDC/" + DATA_NAME + "_DE_" + interval;
        
        try{
            FileReader fstreamin = new FileReader(READ_FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
            HashMap<Integer, PriorityQueue<Delta>> edgeDelta = new HashMap<Integer, PriorityQueue<Delta>>();
            int id = 0;
            while ((strLine = in.readLine()) != null) {
            	id++;
            	String[] values = strLine.split("\t");
            	int stime = Integer.parseInt(values[2]);
            	int etime = Integer.parseInt(values[3]);
            	
            	if(edgeDelta.keySet().contains(stime/interval)) {
            		edgeDelta.get(stime/interval).add(new Delta(id, stime, 0));
                }
            	else {
            		edgeDelta.put(stime/interval, new PriorityQueue<Delta>());
            		edgeDelta.get(stime/interval).add(new Delta(id, stime, 0));
            	}
            	
            	if(edgeDelta.keySet().contains(etime/interval)) {
            		edgeDelta.get(etime/interval).add(new  Delta(id, etime, 1));
                }       
            	else {
            		edgeDelta.put(etime/interval, new PriorityQueue<Delta>());
            		edgeDelta.get(etime/interval).add(new  Delta(id, etime, 1));
            	}
            }
            in.close();

            FileWriter fstreamout_DELTA = new FileWriter(WRITE_DELTA_NAME);
            BufferedWriter out_DELTA = new BufferedWriter(fstreamout_DELTA);

            for(Integer key : edgeDelta.keySet()){
            	out_DELTA.write(key + ":");
                while(!edgeDelta.get(key).isEmpty()){
                	Delta p = edgeDelta.get(key).poll();
                	out_DELTA.write(p.id + "," + p.time + "," + p.operation + "\t");
                }
                out_DELTA.write("\n");
            }
            out_DELTA.close();

        }
        catch (Exception e){
            System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
	}
}
