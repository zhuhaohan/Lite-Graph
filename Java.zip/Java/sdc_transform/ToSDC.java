/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Vector;
import java.util.HashMap;
import java.util.PriorityQueue;

public class ToSDC {

	public static void main(String[] args) {
		
        String FOLDER_NAME  = "/research/datasets/TGA/zhu/";
        String DATA_NAME;
        int interval;
        if(args.length == 1) {
        	DATA_NAME = "FL";
        	interval = Integer.parseInt(args[0]);
        }
        else if(args.length == 2){
        	DATA_NAME = args[0];
        	interval = Integer.parseInt(args[1]);
        }
        else{
        	//DATA_NAME = "NF";
            //DATA_NAME = "AS";
        	DATA_NAME = "CP";
        	//DATA_NAME = "FL";
        	//DATA_NAME = "TA";
        	interval = 100;
        }

        String READ_FILE_NAME = FOLDER_NAME + "TO/" + DATA_NAME + "_TO";
        String WRITE_SNAPSHOT_NAME = FOLDER_NAME + "SDC/" + DATA_NAME + "_" + (interval/1000) + "K_SN";
        String WRITE_DELTA_NAME = FOLDER_NAME + "SDC/" + DATA_NAME + "_" + (interval/1000) + "K_DE";
        
        try{
            FileReader fstreamin = new FileReader(READ_FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
            HashMap<Integer, Vector<Edge>> edgeSnapshot = new HashMap<Integer, Vector<Edge>>();
            HashMap<Integer, PriorityQueue<EdgeDelta>> edgeDelta = new HashMap<Integer, PriorityQueue<EdgeDelta>>();
            
            while ((strLine = in.readLine()) != null) {
            	String[] values = strLine.split("\t");
            	int src = Integer.parseInt(values[0]);
            	int dst = Integer.parseInt(values[1]);
            	int stime = Integer.parseInt(values[2]);
            	int etime = Integer.parseInt(values[3]);
                
            	for (int i = stime; i <= etime; i++){
            		if(i%interval==0){
                    	if(edgeSnapshot.keySet().contains(i/interval)){
                    		edgeSnapshot.get(i/interval).add(new Edge(src, dst, stime, etime));
                        }
                        else{
                        	edgeSnapshot.put(i/interval, new Vector<Edge>());
                        	edgeSnapshot.get(i/interval).add(new Edge(src, dst, stime, etime));
                        }
            		}
            	}
            	
            	if(edgeDelta.keySet().contains(stime/interval)) {
            		edgeDelta.get(stime/interval).add(new EdgeDelta(src, dst, stime, etime, 0));
                }   
            	else {
            		edgeDelta.put(stime/interval, new PriorityQueue<EdgeDelta>());
            		edgeDelta.get(stime/interval).add(new EdgeDelta(src, dst, stime, etime, 0));
            	}
            	
            	if(edgeDelta.keySet().contains(etime/interval)) {
            		edgeDelta.get(etime/interval).add(new EdgeDelta(src, dst, stime, etime, 1));
                }       
            	else {
            		edgeDelta.put(etime/interval, new PriorityQueue<EdgeDelta>());
            		edgeDelta.get(etime/interval).add(new EdgeDelta(src, dst, stime, etime, 1));
            	}
            }
            in.close();
            
            FileWriter fstreamout_SNAPSHOT = new FileWriter(WRITE_SNAPSHOT_NAME);
            BufferedWriter out_SNAPSHOT = new BufferedWriter(fstreamout_SNAPSHOT);
            
            for(Integer key : edgeSnapshot.keySet()){
            	out_SNAPSHOT.write(key + ":");
            	for(Edge p : edgeSnapshot.get(key)){
            		out_SNAPSHOT.write(p.src + "," + p.dst + "," + p.stime + "," + p.etime + "\t");
            	}
            	out_SNAPSHOT.write("\n");
            }
            out_SNAPSHOT.close();

            FileWriter fstreamout_DELTA = new FileWriter(WRITE_DELTA_NAME);
            BufferedWriter out_DELTA = new BufferedWriter(fstreamout_DELTA);

            for(Integer key : edgeDelta.keySet()){
            	out_DELTA.write(key + ":");
                while(!edgeDelta.get(key).isEmpty()){
                	EdgeDelta p = edgeDelta.get(key).poll();
                	out_DELTA.write(p.src + "," + p.dst + "," + p.stime + "," + p.etime + "," + p.operation + "\t");
                }
                out_DELTA.write("\n");
            }
            out_DELTA.close();

        }
        catch (Exception e){
            System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
	}
}
