/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashSet;
import java.util.HashMap;
import java.math.BigInteger;

public class SpaceCheck {
    
	public static void main(String[] args) {

        String FILE_NAME;
        if(args.length != 1){
            //FILE_NAME = "/scratch/zhu/original_data/Flight_TGA";
            //FILE_NAME = "/scratch/zhu/original_data/Orange12h_TGA";
        	//FILE_NAME = "/scratch/zhu/original_data/AS_new_TGA";
            //FILE_NAME = "/scratch/zhu/original_data/NF_TGA";
        	FILE_NAME = "/scratch/zhu/original_data/TA_new_TGA";

        }
        else{
            FILE_NAME = args[0];    
        }
        
        try{
            FileReader fstreamin = new FileReader(FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
            BigInteger countOfEdgeStream = BigInteger.ZERO;
            BigInteger countOfSnapshotSequence = BigInteger.ZERO;
            BigInteger countOfChronousInMemory = BigInteger.ZERO;
            BigInteger countOfChronousCompactInMemory = BigInteger.ZERO;
            BigInteger countOfChronousOnDiskSparse = BigInteger.ZERO;
            BigInteger countOfChronousOnDiskDense = BigInteger.ZERO;
            int count = 0;
            HashSet<Integer> nodeSet = new HashSet<Integer>();
            HashSet<Integer> timeSet = new HashSet<Integer>();
            HashMap<Integer, HashSet<Integer>> edgeMap = new HashMap<Integer, HashSet<Integer>>();
            
            while ((strLine = in.readLine()) != null) {
            	count++;
                String[] values = strLine.split("\t");
                int src = Integer.parseInt(values[0]);
                int dst = Integer.parseInt(values[1]);
                int start = Integer.parseInt(values[2]);
                int end = Integer.parseInt(values[3]);
                int duration = end - start + 1;
                timeSet.add(start);
                timeSet.add(end);
                nodeSet.add(src);
                nodeSet.add(dst);
                if(edgeMap.keySet().contains(src)){
                	edgeMap.get(src).add(dst);
                }
                else{
                	edgeMap.put(src, new HashSet<Integer>());
                	edgeMap.get(src).add(dst);
                }
                int tmp1 = 4*duration;
                int tmp2 = 0;
                for(int i = start; i<=end; i++){
                	if(i%100==0) {
                		tmp2 += 4;
                	}
                }
                tmp2 += 8;
                int tmp3 = 0;
                for(int i = start; i<=end; i++){
                	if(i%10==0) {
                		tmp3 += 4;
                	}
                }
                tmp3 += 8;
                countOfEdgeStream = countOfEdgeStream.add(BigInteger.valueOf(4));
                countOfSnapshotSequence = countOfSnapshotSequence.add(BigInteger.valueOf(tmp1));
                countOfChronousOnDiskSparse = countOfChronousOnDiskSparse.add(BigInteger.valueOf(tmp2));
                countOfChronousOnDiskDense = countOfChronousOnDiskDense.add(BigInteger.valueOf(tmp3));
                if(count%10000000==0)
                	System.out.println(count + " edges have been processed");
            }
            in.close();
            long distinctEdges = 0;
            for(Integer key : edgeMap.keySet()){
            	distinctEdges += edgeMap.get(key).size();
            }
            countOfSnapshotSequence = countOfSnapshotSequence.add(BigInteger.valueOf(timeSet.size()));
            countOfChronousInMemory = BigInteger.valueOf(count);
            countOfChronousInMemory = countOfChronousInMemory.multiply(BigInteger.valueOf(timeSet.size()));
            countOfChronousInMemory = countOfChronousInMemory.divide(BigInteger.valueOf(32));
            countOfChronousInMemory = countOfChronousInMemory.add(BigInteger.valueOf(count));
            countOfChronousInMemory = countOfChronousInMemory.add(BigInteger.valueOf(nodeSet.size()));
            countOfChronousCompactInMemory = BigInteger.valueOf(distinctEdges);
            countOfChronousCompactInMemory = countOfChronousCompactInMemory.multiply(BigInteger.valueOf(timeSet.size()+1));
            countOfChronousCompactInMemory = countOfChronousCompactInMemory.add(BigInteger.valueOf(nodeSet.size()));
            countOfChronousOnDiskSparse = countOfChronousOnDiskSparse.add(BigInteger.valueOf(count/16));
            countOfChronousOnDiskDense = countOfChronousOnDiskDense.add(BigInteger.valueOf(count/16));
            BigInteger GB = BigInteger.valueOf(268435456);
            BigInteger MB = BigInteger.valueOf(262144);
            System.out.println("# Nodes\t" + nodeSet.size());
            System.out.println("# Edges\t" + count);
            System.out.println("# Times\t" + timeSet.size());
            System.out.println("# Distinct Edges\t" + distinctEdges);
            System.out.println("Edge_Stream\t" + countOfEdgeStream.divide(GB) + "\t(GB)");
            System.out.println("Snapshot_Sequence\t" + countOfSnapshotSequence.divide(GB) + "\t(GB)");
            System.out.println("Edge_Bitmap\t" + countOfChronousInMemory.divide(GB) + "\t(GB)");
            System.out.println("Compact_Edge_Bitmap\t" + countOfChronousCompactInMemory.divide(GB) + "\t(GB)");
            System.out.println("Sparse_Snapshot-Delta\t" + countOfChronousOnDiskSparse.divide(GB) + "\t(GB)");
            System.out.println("Dense_Snapshot-Delta\t" + countOfChronousOnDiskDense.divide(GB) + "\t(GB)");
            System.out.println("Edge_Stream\t" + countOfEdgeStream.divide(MB) + "\t(MB)");
            System.out.println("Snapshot_Sequence\t" + countOfSnapshotSequence.divide(MB) + "\t(MB)");
            System.out.println("Edge_Bitmap\t" + countOfChronousInMemory.divide(MB) + "\t(MB)");
            System.out.println("Compact_Edge_Bitmap\t" + countOfChronousCompactInMemory.divide(MB) + "\t(MB)");
            System.out.println("Sparse_Snapshot-Delta\t" + countOfChronousOnDiskSparse.divide(MB) + "\t(MB)");
            System.out.println("Dense_Snapshot-Delta\t" + countOfChronousOnDiskDense.divide(MB) + "\t(MB)");
        }
        catch (Exception e){
                    System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
    }
	
	
}

