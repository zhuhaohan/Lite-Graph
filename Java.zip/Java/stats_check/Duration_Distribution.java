/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.PriorityQueue;

public class Duration_Distribution {
    
	public static void main(String[] args) {

        String FILE_NAME;
        if(args.length != 1){
            //FILE_NAME = "/scratch/zhu/original_data/Flight_TGA";
            //FILE_NAME = "/scratch/zhu/original_data/Orange12h_TGA";
        	//FILE_NAME = "/scratch/zhu/original_data/AS_new_TGA";
            //FILE_NAME = "/scratch/zhu/original_data/NF_TGA";
        	FILE_NAME = "/scratch/zhu/original_data/TA_new_TGA";
        }
        else{
            FILE_NAME = args[0];    
        }

        HashMap<Integer, Integer> durationMap = new HashMap<Integer, Integer>();
        int maxDuration = 0;
        int minStart = 999999999;
        int maxEnd = 0;
        
        try{
            FileReader fstreamin = new FileReader(FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
       
            while ((strLine = in.readLine()) != null) {
                String[] values = strLine.split("\t");
                int start = Integer.parseInt(values[2]);
                int end = Integer.parseInt(values[3]);
                int duration = end - start;
                if(duration > maxDuration)
                	maxDuration = duration;
                if(start < minStart)
                	minStart = start;
                if(end > maxEnd)
                	maxEnd = end;              
                
                if (durationMap.containsKey(duration)) {
                	durationMap.put(duration, (durationMap.get(duration)+1));
                }
                else {
                	durationMap.put(duration, 1);
                }
                
            }
            in.close();
        }
        catch (Exception e){
                    System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }

        System.out.println("# Duration:\t" + durationMap.size());
        System.out.println("Max Duration:\t" + maxDuration);
        System.out.println("Max Range:\t" + (maxEnd-minStart));
        
        PriorityQueue<Pair> durationQueue = new PriorityQueue<Pair>();
            
        for(int key : durationMap.keySet()){
        	durationQueue.add(new Pair(key, durationMap.get(key)));
        }
        int k = 0;
        try {
            FileWriter fstreamout_durationQueue  = new FileWriter("/home/grad2/zhu/Documents/Duration_Distribution.txt");
            BufferedWriter out_durationQueue = new BufferedWriter(fstreamout_durationQueue);
            while(!durationQueue.isEmpty()){
            	Pair p = durationQueue.poll();
            	if(k%20==0)
            		out_durationQueue.write(p.key + "\t" + p.value + "\n");
            	k++;
            }
            out_durationQueue.close();
        }
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
    }
}