/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.FileReader;

public class Largest_Node_Number {
	public static void main(String[] args) {

        String FILE_NAME;
        if(args.length != 1){
            //FILE_NAME = "/research/datasets/TGA/zhu/FL/FL_PO_10K";
            //FILE_NAME = "/research/datasets/TGA/zhu/CP/CP_PO_5K";
        	//FILE_NAME = "/research/datasets/TGA/zhu/AS/AS_PO_1K";
            //FILE_NAME = "/research/datasets/TGA/zhu/NF/NF_PO_100K";
        	FILE_NAME = "/research/datasets/TGA/zhu/TA/TA_PO_100K";
        }
        else{
            FILE_NAME = args[0];
        }
        
        try{
            FileReader fstreamin = new FileReader(FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
            int maxNode = 0;
            int minNode = 999999999;
        
            while ((strLine = in.readLine()) != null) {
                String[] values = strLine.split("\t");
                int src = Integer.parseInt(values[0]);
                int dst = Integer.parseInt(values[1]);
                
                if (maxNode < src)
                	maxNode = src;
                if (maxNode < dst)
                	maxNode = dst;
                if (minNode > src)
                	minNode = src;
                if (minNode > dst)
                	minNode = dst;
            }
            in.close();
            System.out.println("Max Node Number\t" + maxNode);
            System.out.println("Min Node Number\t" + minNode);
        }
        catch (Exception e){
                    System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
    }
}
