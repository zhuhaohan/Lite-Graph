public class Pair implements Comparable<Pair>{  
	public int key;
	public int value;
	
	public Pair (int key, int value) {
		this.key = key;
		this.value = value;
	}	
        
	@Override
    public int compareTo(Pair other){
		if(this.key != other.key)
			return new Integer(this.key).compareTo(other.key);
		else
			return new Integer(this.value).compareTo(other.value);
	}
}