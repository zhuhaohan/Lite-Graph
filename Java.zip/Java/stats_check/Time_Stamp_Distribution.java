/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.HashMap;
import java.util.PriorityQueue;

public class Time_Stamp_Distribution {
    
	public static void main(String[] args) {

        String FILE_NAME;
        if(args.length != 1){
            //FILE_NAME = "/research/datasets/Flight/TGA/Fligtht_TGA";
        	//FILE_NAME = "/research/datasets/NYC_Taxi/TGA/Taxi-2000N_TGA";
        	//FILE_NAME = "/research/datasets/AS_UCLA/AS_TGA";
            //FILE_NAME = "/research/datasets/NF-Yahoo/NF_TGA";
        	FILE_NAME = "/research/datasets/Orange/TGA/Orange_TGA";
        }
        else{
            FILE_NAME = args[0];    
        }
        
        HashMap<Integer, Integer> startTimeMap = new HashMap<Integer, Integer>();
        HashMap<Integer, Integer> endTimeMap = new HashMap<Integer, Integer>();
        HashMap<Integer, Integer> durationMap = new HashMap<Integer, Integer>();
        
        try{
            FileReader fstreamin = new FileReader(FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
       
            while ((strLine = in.readLine()) != null) {
                String[] values = strLine.split("\t");
                int start = Integer.parseInt(values[2]);
                int end = Integer.parseInt(values[3]);
                int duration = end - start;

                if (startTimeMap.containsKey(start)) {
                	startTimeMap.put(start, (startTimeMap.get(start)+1));
                }
                else {
                	startTimeMap.put(start, 1);
                } 
                
                if (endTimeMap.containsKey(end)) {
                	endTimeMap.put(end, (endTimeMap.get(end)+1));
                }
                else {
                	endTimeMap.put(end, 1);
                }
                
                if (durationMap.containsKey(duration)) {
                	durationMap.put(duration, (durationMap.get(duration)+1));
                }
                else {
                	durationMap.put(duration, 1);
                } 
                
            }
            in.close();
        }
        catch (Exception e){
                    System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }

        System.out.println("# Starting Time:\t" + startTimeMap.size());
        System.out.println("# Ending Time:\t" + endTimeMap.size());
        System.out.println("# Duration:\t" + durationMap.size());
        
        HashMap<Integer, Integer> startTimeFrequency = new HashMap<Integer, Integer>();
        HashMap<Integer, Integer> endTimeFrequency = new HashMap<Integer, Integer>();

        for(int key : startTimeMap.keySet()){
            int value = startTimeMap.get(key);
            if (startTimeFrequency.containsKey(value)) {
                startTimeFrequency.put(value, (startTimeFrequency.get(value)+1));
            }
            else {
                startTimeFrequency.put(value, 1);
            }
        }
            
        for(int key : endTimeMap.keySet()){
        	int value = endTimeMap.get(key);
        	if (endTimeFrequency.containsKey(value)) {
        		endTimeFrequency.put(value, (endTimeFrequency.get(value)+1));
        	}
        	else {
        		endTimeFrequency.put(value, 1);
        	}
        }

        PriorityQueue<Pair> startTimeQueue = new PriorityQueue<Pair>();
        PriorityQueue<Pair> endTimeQueue = new PriorityQueue<Pair>();
        PriorityQueue<Pair> durationQueue = new PriorityQueue<Pair>();
            
        for(int key : startTimeFrequency.keySet()){
        	startTimeQueue.add(new Pair(key, startTimeFrequency.get(key)));
        }
        
        for(int key : endTimeFrequency.keySet()){
        	endTimeQueue.add(new Pair(key, endTimeFrequency.get(key)));
        }
        
        for(int key : durationMap.keySet()){
        	durationQueue.add(new Pair(key, durationMap.get(key)));
        }

        try {
            FileWriter fstreamout_startTimeQueue  = new FileWriter("/home/grad2/zhu/Documents/startTimeDistribution.txt");
            BufferedWriter out_startTimeQueue = new BufferedWriter(fstreamout_startTimeQueue);
            while(!startTimeQueue.isEmpty()){
            	Pair p = startTimeQueue.poll();
            	out_startTimeQueue.write(p.key + "\t" + p.value + "\n");
            }
            out_startTimeQueue.close();
            	
            FileWriter fstreamout_endTimeQueue  = new FileWriter("/home/grad2/zhu/Documents/endTimeDistribution.txt");
            BufferedWriter out_endTimeQueue = new BufferedWriter(fstreamout_endTimeQueue);
            while(!endTimeQueue.isEmpty()){
            	Pair p = endTimeQueue.poll();
            	out_endTimeQueue.write(p.key + "\t" + p.value + "\n");
            }
            out_endTimeQueue.close();
            
            FileWriter fstreamout_durationQueue  = new FileWriter("/home/grad2/zhu/Documents/DurationDistribution.txt");
            BufferedWriter out_durationQueue = new BufferedWriter(fstreamout_durationQueue);
            while(!durationQueue.isEmpty()){
            	Pair p = durationQueue.poll();
            	out_durationQueue.write(p.key + "\t" + p.value + "\n");
            }
            out_durationQueue.close();

        }
        catch (Exception e){
            System.err.println("Error: " + e.getMessage());
        }
    }
}

