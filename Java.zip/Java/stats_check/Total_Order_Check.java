/**
 * @author Haohan Zhu
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashSet;

public class Total_Order_Check {
    
	public static void main(String[] args) {

        String FILE_NAME;
        if(args.length != 1){
            //FILE_NAME = "/scratch/zhu/original_data/Flight_TGA";
            //FILE_NAME = "/scratch/zhu/original_data/Orange12h_TGA";
        	//FILE_NAME = "/scratch/zhu/original_data/AS_new_TGA";
            //FILE_NAME = "/scratch/zhu/original_data/NF_TGA";
        	FILE_NAME = "/scratch/zhu/original_data/TA_new_TGA";
        }
        else{
            FILE_NAME = args[0];
        }
        
        try{
            FileReader fstreamin = new FileReader(FILE_NAME);
            BufferedReader in = new BufferedReader(fstreamin);
            String strLine;
            int currentTime = 0;
            int wrongOrderTime = 0;
            int numberOfEdges = 0;
            int smallestStartTime = 999999999;
            int largestStartTime = 0;
            int smallestEndTime = 999999999;
            int largestEndTime = 0;
            int smallestDuration = 999999999;
            int largestDuration = 0;
            HashSet<Integer> nodeSet = new HashSet<Integer>();
            HashSet<Integer> timeSet = new HashSet<Integer>();
        
            while ((strLine = in.readLine()) != null) {
                String[] values = strLine.split("\t");
                int src = Integer.parseInt(values[0]);
                int dst = Integer.parseInt(values[1]);
                int start = Integer.parseInt(values[2]);
                int end = Integer.parseInt(values[3]);
                int duration = end - start;
                                
                nodeSet.add(src);
                nodeSet.add(dst);
                timeSet.add(start);
                timeSet.add(end);
                
                if (start > largestStartTime)
                    largestStartTime = start;
                if (start < smallestStartTime)
                    smallestStartTime = start;
                if (end > largestEndTime)
                    largestEndTime = end;
                if (end < smallestEndTime)
                    smallestEndTime = end;
                if (duration > largestDuration)
                	largestDuration = duration;
                if (duration < smallestDuration)
                	smallestDuration = duration;
                if (currentTime > start){
                    wrongOrderTime++;
                }
                else{
                    currentTime = start;
                }
                
                numberOfEdges++;
            }
            in.close();
            System.out.println("Disordered Edges\t" + wrongOrderTime);
            System.out.println("# Edges\t" + numberOfEdges);
            System.out.println("# Nodes\t" + nodeSet.size());
            System.out.println("# Times\t" + timeSet.size());
            System.out.println("Min Start Time\t" + smallestStartTime);
            System.out.println("Max Start Time\t" + largestStartTime);
            System.out.println("Min End Time\t" + smallestEndTime);
            System.out.println("Max End Time\t" + largestEndTime);
            System.out.println("Min Duration\t" + smallestDuration);
            System.out.println("Max Duration\t" + largestDuration);
        }
        catch (Exception e){
                    System.err.println("Error: " + e.toString() + "|" + e.getMessage());
        }
    }
	
	
}

